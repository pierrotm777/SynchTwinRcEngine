﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TrackBarMotors = New System.Windows.Forms.TrackBar()
        Me.LabelMotors = New System.Windows.Forms.Label()
        Me.ButtonExit = New System.Windows.Forms.Button()
        Me.ComboPort = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ComboBaudRate = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ButtonSauvegardeCOM = New System.Windows.Forms.Button()
        Me.ButtonSettings = New System.Windows.Forms.Button()
        Me.ButtonServoAuto = New System.Windows.Forms.Button()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.PictureBoxGlowPlugOnOff = New System.Windows.Forms.PictureBox()
        Me.ButtonGlowPlugOnOff = New System.Windows.Forms.Button()
        Me.PictureBoxGlowPlug = New System.Windows.Forms.PictureBox()
        Me.ProgressBarAuxiliary = New System.Windows.Forms.ProgressBar()
        Me.TrackBarRudder = New System.Windows.Forms.TrackBar()
        Me.PictureBoxAuxMaxi = New System.Windows.Forms.PictureBox()
        Me.PictureBoxAuxMiddle = New System.Windows.Forms.PictureBox()
        Me.PictureBoxAuxMini = New System.Windows.Forms.PictureBox()
        Me.ButtonAuxMaxi = New System.Windows.Forms.Button()
        Me.ButtonAuxMiddle = New System.Windows.Forms.Button()
        Me.ButtonAuxMini = New System.Windows.Forms.Button()
        Me.LabelAuxiRudder = New System.Windows.Forms.Label()
        Me.ProgressBarThrottle = New System.Windows.Forms.ProgressBar()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.LabelAux = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.ButtonAbout = New System.Windows.Forms.Button()
        Me.txtMessage = New System.Windows.Forms.TextBox()
        Me.btnSend = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.PictureBoxConnectedOK = New System.Windows.Forms.PictureBox()
        Me.Button_Connect = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.textGeneralMinMaxStopWatch = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.CheckBoxInversionAux = New System.Windows.Forms.CheckBox()
        Me.LabelDEBUG = New System.Windows.Forms.Label()
        Me.TextBoxDEBUG = New System.Windows.Forms.TextBox()
        Me.CheckBoxFahrenheitDegrees = New System.Windows.Forms.CheckBox()
        Me.ButtonMoteurs = New System.Windows.Forms.Button()
        Me.ButtonModuleType = New System.Windows.Forms.Button()
        Me.ButtonReadTempVoltage = New System.Windows.Forms.Button()
        Me.PictureBoxTimer2OnOff = New System.Windows.Forms.PictureBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.ButtonReadAuxiliairePulse = New System.Windows.Forms.Button()
        Me.TextBoxAuxiliairePulse = New System.Windows.Forms.TextBox()
        Me.ButtonAuxiliaireHelp = New System.Windows.Forms.Button()
        Me.LabelInterType = New System.Windows.Forms.Label()
        Me.ButtonMiniMaxGeneral = New System.Windows.Forms.Button()
        Me.ButtonDebutSynchro = New System.Windows.Forms.Button()
        Me.ButtonMaxiMoteurs = New System.Windows.Forms.Button()
        Me.ButtonIdleMoteur2 = New System.Windows.Forms.Button()
        Me.ButtonIdleMoteur1 = New System.Windows.Forms.Button()
        Me.ButtonReadCenter2 = New System.Windows.Forms.Button()
        Me.ButtonReadCenter1 = New System.Windows.Forms.Button()
        Me.ButtonConfigDefaut = New System.Windows.Forms.Button()
        Me.ButtonPlusNombrePales = New System.Windows.Forms.Button()
        Me.ButtonPlusTelemetrie = New System.Windows.Forms.Button()
        Me.ButtonMoinsTelemetrie = New System.Windows.Forms.Button()
        Me.ButtonMoinsNombrePales = New System.Windows.Forms.Button()
        Me.ButtonPlusModeAuxiliaire = New System.Windows.Forms.Button()
        Me.ButtonMoinsModeAuxiliaire = New System.Windows.Forms.Button()
        Me.ButtonPlusVitesseReponse = New System.Windows.Forms.Button()
        Me.ButtonMoinsVitesseReponse = New System.Windows.Forms.Button()
        Me.LabelModifications = New System.Windows.Forms.Label()
        Me.ButtonAnnulerModif = New System.Windows.Forms.Button()
        Me.CheckBoxInversionServo2 = New System.Windows.Forms.CheckBox()
        Me.CheckBoxInversionServo1 = New System.Windows.Forms.CheckBox()
        Me.TextVoltageExterne = New System.Windows.Forms.TextBox()
        Me.TextTempInterne = New System.Windows.Forms.TextBox()
        Me.TextVoltageInterne = New System.Windows.Forms.TextBox()
        Me.textNombrePales = New System.Windows.Forms.TextBox()
        Me.textAddresseI2C = New System.Windows.Forms.TextBox()
        Me.textTelemetrieType = New System.Windows.Forms.TextBox()
        Me.textAuxiliaireMode = New System.Windows.Forms.TextBox()
        Me.textMaxiGenerale = New System.Windows.Forms.TextBox()
        Me.textMiniGenerale = New System.Windows.Forms.TextBox()
        Me.textDebutSynchro = New System.Windows.Forms.TextBox()
        Me.textMaxiMoteurs = New System.Windows.Forms.TextBox()
        Me.textTempsReponse = New System.Windows.Forms.TextBox()
        Me.textIdleServo2 = New System.Windows.Forms.TextBox()
        Me.textIdleServo1 = New System.Windows.Forms.TextBox()
        Me.textCentreServo2 = New System.Windows.Forms.TextBox()
        Me.textCentreServo1 = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.ButtonSauvegardeConfig = New System.Windows.Forms.Button()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.PictureBoxTimer1OnOff = New System.Windows.Forms.PictureBox()
        Me.ButtonReadSpeeds = New System.Windows.Forms.Button()
        Me.TimerSpeeds = New System.Windows.Forms.Timer(Me.components)
        Me.TimerRXAuxiliaire = New System.Windows.Forms.Timer(Me.components)
        Me.TimerRXMotors = New System.Windows.Forms.Timer(Me.components)
        Me.TimerHardwareInfos = New System.Windows.Forms.Timer(Me.components)
        Me.Moteurs = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBoxForceSpeedSimu2 = New System.Windows.Forms.TextBox()
        Me.TrackBarSpeedSimu2 = New System.Windows.Forms.TrackBar()
        Me.TrackBarSpeedSimu1 = New System.Windows.Forms.TrackBar()
        Me.ButtonDiffSpeedSimuConsigne = New System.Windows.Forms.Button()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.TextBoxDiffSpeedSimuConsigne = New System.Windows.Forms.TextBox()
        Me.TextBoxForceSpeedSimu1 = New System.Windows.Forms.TextBox()
        Me.ButtonSpeedSimuOn = New System.Windows.Forms.Button()
        Me.ButtonDataLogger = New System.Windows.Forms.Button()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.AquaGaugeMoteur2 = New AquaControls.AquaGauge()
        Me.AquaGaugeMoteur1 = New AquaControls.AquaGauge()
        Me.LabelVitesse1 = New System.Windows.Forms.Label()
        Me.LabelVitesse2 = New System.Windows.Forms.Label()
        Me.CheckBoxSimuSynchroSpeeds = New System.Windows.Forms.CheckBox()
        Me.DataLogger = New System.Windows.Forms.GroupBox()
        Me.zg1 = New ZedGraph.ZedGraphControl()
        Me.TimerDataLogger = New System.Windows.Forms.Timer(Me.components)
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.ProgressBarThrottleMotors = New SynchTwinRcEngine_Interface.UcV_ProgressBar()
        CType(Me.TrackBarMotors, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBoxGlowPlugOnOff, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxGlowPlug, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarRudder, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxAuxMaxi, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxAuxMiddle, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxAuxMini, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBoxConnectedOK, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.PictureBoxTimer2OnOff, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxTimer1OnOff, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Moteurs.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.TrackBarSpeedSimu2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarSpeedSimu1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.DataLogger.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(65, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(204, 19)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Canal Moteurs Simulation"
        '
        'TrackBarMotors
        '
        Me.TrackBarMotors.LargeChange = 10
        Me.TrackBarMotors.Location = New System.Drawing.Point(58, 34)
        Me.TrackBarMotors.Maximum = 180
        Me.TrackBarMotors.Name = "TrackBarMotors"
        Me.TrackBarMotors.Size = New System.Drawing.Size(213, 45)
        Me.TrackBarMotors.SmallChange = 10
        Me.TrackBarMotors.TabIndex = 2
        Me.TrackBarMotors.TickFrequency = 10
        Me.TrackBarMotors.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        '
        'LabelMotors
        '
        Me.LabelMotors.AutoSize = True
        Me.LabelMotors.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMotors.Location = New System.Drawing.Point(277, 46)
        Me.LabelMotors.Name = "LabelMotors"
        Me.LabelMotors.Size = New System.Drawing.Size(21, 22)
        Me.LabelMotors.TabIndex = 3
        Me.LabelMotors.Text = "0"
        Me.LabelMotors.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ButtonExit
        '
        Me.ButtonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.ButtonExit.Location = New System.Drawing.Point(295, 218)
        Me.ButtonExit.Name = "ButtonExit"
        Me.ButtonExit.Size = New System.Drawing.Size(75, 23)
        Me.ButtonExit.TabIndex = 4
        Me.ButtonExit.Text = "Quitter"
        Me.ButtonExit.UseVisualStyleBackColor = True
        '
        'ComboPort
        '
        Me.ComboPort.FormattingEnabled = True
        Me.ComboPort.Location = New System.Drawing.Point(46, 19)
        Me.ComboPort.Name = "ComboPort"
        Me.ComboPort.Size = New System.Drawing.Size(79, 21)
        Me.ComboPort.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(3, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 16)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Com  :"
        '
        'ComboBaudRate
        '
        Me.ComboBaudRate.FormattingEnabled = True
        Me.ComboBaudRate.Location = New System.Drawing.Point(46, 46)
        Me.ComboBaudRate.Name = "ComboBaudRate"
        Me.ComboBaudRate.Size = New System.Drawing.Size(79, 21)
        Me.ComboBaudRate.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(3, 47)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 16)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Baud :"
        '
        'ButtonSauvegardeCOM
        '
        Me.ButtonSauvegardeCOM.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.ButtonSauvegardeCOM.Location = New System.Drawing.Point(169, 47)
        Me.ButtonSauvegardeCOM.Name = "ButtonSauvegardeCOM"
        Me.ButtonSauvegardeCOM.Size = New System.Drawing.Size(105, 23)
        Me.ButtonSauvegardeCOM.TabIndex = 10
        Me.ButtonSauvegardeCOM.Text = "Sauvegarde"
        Me.ButtonSauvegardeCOM.UseVisualStyleBackColor = True
        '
        'ButtonSettings
        '
        Me.ButtonSettings.Location = New System.Drawing.Point(269, 85)
        Me.ButtonSettings.Name = "ButtonSettings"
        Me.ButtonSettings.Size = New System.Drawing.Size(105, 23)
        Me.ButtonSettings.TabIndex = 16
        Me.ButtonSettings.Text = "Configuration  >>"
        Me.ButtonSettings.UseVisualStyleBackColor = True
        '
        'ButtonServoAuto
        '
        Me.ButtonServoAuto.Location = New System.Drawing.Point(326, 45)
        Me.ButtonServoAuto.Name = "ButtonServoAuto"
        Me.ButtonServoAuto.Size = New System.Drawing.Size(44, 23)
        Me.ButtonServoAuto.TabIndex = 18
        Me.ButtonServoAuto.Text = "Auto"
        Me.ButtonServoAuto.UseVisualStyleBackColor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox2.Image = Global.SynchTwinRcEngine_Interface.My.Resources.Resources.joystick
        Me.PictureBox2.Location = New System.Drawing.Point(8, 30)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(51, 45)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 14
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox1.Image = Global.SynchTwinRcEngine_Interface.My.Resources.Resources.Mosquito
        Me.PictureBox1.Location = New System.Drawing.Point(7, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(87, 51)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.PictureBoxGlowPlugOnOff)
        Me.GroupBox1.Controls.Add(Me.ButtonGlowPlugOnOff)
        Me.GroupBox1.Controls.Add(Me.PictureBoxGlowPlug)
        Me.GroupBox1.Controls.Add(Me.ProgressBarAuxiliary)
        Me.GroupBox1.Controls.Add(Me.TrackBarRudder)
        Me.GroupBox1.Controls.Add(Me.PictureBoxAuxMaxi)
        Me.GroupBox1.Controls.Add(Me.PictureBoxAuxMiddle)
        Me.GroupBox1.Controls.Add(Me.PictureBoxAuxMini)
        Me.GroupBox1.Controls.Add(Me.ButtonAuxMaxi)
        Me.GroupBox1.Controls.Add(Me.ButtonAuxMiddle)
        Me.GroupBox1.Controls.Add(Me.ButtonAuxMini)
        Me.GroupBox1.Controls.Add(Me.LabelAuxiRudder)
        Me.GroupBox1.Controls.Add(Me.ProgressBarThrottle)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.LabelAux)
        Me.GroupBox1.Controls.Add(Me.PictureBox3)
        Me.GroupBox1.Controls.Add(Me.TrackBarMotors)
        Me.GroupBox1.Controls.Add(Me.ButtonServoAuto)
        Me.GroupBox1.Controls.Add(Me.PictureBox2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.LabelMotors)
        Me.GroupBox1.Controls.Add(Me.ButtonExit)
        Me.GroupBox1.Location = New System.Drawing.Point(4, 107)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(378, 247)
        Me.GroupBox1.TabIndex = 22
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Test Servos"
        '
        'PictureBoxGlowPlugOnOff
        '
        Me.PictureBoxGlowPlugOnOff.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBoxGlowPlugOnOff.Location = New System.Drawing.Point(174, 222)
        Me.PictureBoxGlowPlugOnOff.Name = "PictureBoxGlowPlugOnOff"
        Me.PictureBoxGlowPlugOnOff.Size = New System.Drawing.Size(13, 16)
        Me.PictureBoxGlowPlugOnOff.TabIndex = 125
        Me.PictureBoxGlowPlugOnOff.TabStop = False
        '
        'ButtonGlowPlugOnOff
        '
        Me.ButtonGlowPlugOnOff.Location = New System.Drawing.Point(69, 218)
        Me.ButtonGlowPlugOnOff.Name = "ButtonGlowPlugOnOff"
        Me.ButtonGlowPlugOnOff.Size = New System.Drawing.Size(99, 23)
        Me.ButtonGlowPlugOnOff.TabIndex = 137
        Me.ButtonGlowPlugOnOff.Text = "Bougies On/Off"
        Me.ButtonGlowPlugOnOff.UseVisualStyleBackColor = True
        '
        'PictureBoxGlowPlug
        '
        Me.PictureBoxGlowPlug.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBoxGlowPlug.Image = Global.SynchTwinRcEngine_Interface.My.Resources.Resources.GlowPlug
        Me.PictureBoxGlowPlug.Location = New System.Drawing.Point(8, 176)
        Me.PictureBoxGlowPlug.Name = "PictureBoxGlowPlug"
        Me.PictureBoxGlowPlug.Size = New System.Drawing.Size(51, 65)
        Me.PictureBoxGlowPlug.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxGlowPlug.TabIndex = 136
        Me.PictureBoxGlowPlug.TabStop = False
        '
        'ProgressBarAuxiliary
        '
        Me.ProgressBarAuxiliary.Location = New System.Drawing.Point(69, 157)
        Me.ProgressBarAuxiliary.Maximum = 180
        Me.ProgressBarAuxiliary.Name = "ProgressBarAuxiliary"
        Me.ProgressBarAuxiliary.Size = New System.Drawing.Size(192, 23)
        Me.ProgressBarAuxiliary.TabIndex = 134
        '
        'TrackBarRudder
        '
        Me.TrackBarRudder.LargeChange = 10
        Me.TrackBarRudder.Location = New System.Drawing.Point(58, 119)
        Me.TrackBarRudder.Maximum = 180
        Me.TrackBarRudder.Name = "TrackBarRudder"
        Me.TrackBarRudder.Size = New System.Drawing.Size(213, 45)
        Me.TrackBarRudder.SmallChange = 10
        Me.TrackBarRudder.TabIndex = 135
        Me.TrackBarRudder.TickFrequency = 10
        Me.TrackBarRudder.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        '
        'PictureBoxAuxMaxi
        '
        Me.PictureBoxAuxMaxi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBoxAuxMaxi.Location = New System.Drawing.Point(263, 123)
        Me.PictureBoxAuxMaxi.Name = "PictureBoxAuxMaxi"
        Me.PictureBoxAuxMaxi.Size = New System.Drawing.Size(10, 16)
        Me.PictureBoxAuxMaxi.TabIndex = 133
        Me.PictureBoxAuxMaxi.TabStop = False
        '
        'PictureBoxAuxMiddle
        '
        Me.PictureBoxAuxMiddle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBoxAuxMiddle.Location = New System.Drawing.Point(189, 124)
        Me.PictureBoxAuxMiddle.Name = "PictureBoxAuxMiddle"
        Me.PictureBoxAuxMiddle.Size = New System.Drawing.Size(10, 16)
        Me.PictureBoxAuxMiddle.TabIndex = 132
        Me.PictureBoxAuxMiddle.TabStop = False
        '
        'PictureBoxAuxMini
        '
        Me.PictureBoxAuxMini.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBoxAuxMini.Location = New System.Drawing.Point(115, 124)
        Me.PictureBoxAuxMini.Name = "PictureBoxAuxMini"
        Me.PictureBoxAuxMini.Size = New System.Drawing.Size(10, 16)
        Me.PictureBoxAuxMini.TabIndex = 125
        Me.PictureBoxAuxMini.TabStop = False
        '
        'ButtonAuxMaxi
        '
        Me.ButtonAuxMaxi.Location = New System.Drawing.Point(217, 120)
        Me.ButtonAuxMaxi.Name = "ButtonAuxMaxi"
        Me.ButtonAuxMaxi.Size = New System.Drawing.Size(44, 23)
        Me.ButtonAuxMaxi.TabIndex = 131
        Me.ButtonAuxMaxi.Text = "On"
        Me.ButtonAuxMaxi.UseVisualStyleBackColor = True
        '
        'ButtonAuxMiddle
        '
        Me.ButtonAuxMiddle.Location = New System.Drawing.Point(142, 120)
        Me.ButtonAuxMiddle.Name = "ButtonAuxMiddle"
        Me.ButtonAuxMiddle.Size = New System.Drawing.Size(44, 23)
        Me.ButtonAuxMiddle.TabIndex = 130
        Me.ButtonAuxMiddle.Text = "Milieu"
        Me.ButtonAuxMiddle.UseVisualStyleBackColor = True
        '
        'ButtonAuxMini
        '
        Me.ButtonAuxMini.Location = New System.Drawing.Point(69, 120)
        Me.ButtonAuxMini.Name = "ButtonAuxMini"
        Me.ButtonAuxMini.Size = New System.Drawing.Size(44, 23)
        Me.ButtonAuxMini.TabIndex = 129
        Me.ButtonAuxMini.Text = "Off"
        Me.ButtonAuxMini.UseVisualStyleBackColor = True
        '
        'LabelAuxiRudder
        '
        Me.LabelAuxiRudder.AutoSize = True
        Me.LabelAuxiRudder.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelAuxiRudder.Location = New System.Drawing.Point(63, 99)
        Me.LabelAuxiRudder.Name = "LabelAuxiRudder"
        Me.LabelAuxiRudder.Size = New System.Drawing.Size(211, 19)
        Me.LabelAuxiRudder.TabIndex = 128
        Me.LabelAuxiRudder.Text = "Canal Auxiliaire Simulation"
        '
        'ProgressBarThrottle
        '
        Me.ProgressBarThrottle.Location = New System.Drawing.Point(69, 72)
        Me.ProgressBarThrottle.Maximum = 180
        Me.ProgressBarThrottle.Name = "ProgressBarThrottle"
        Me.ProgressBarThrottle.Size = New System.Drawing.Size(192, 23)
        Me.ProgressBarThrottle.TabIndex = 126
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(314, 131)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(54, 20)
        Me.Label4.TabIndex = 124
        Me.Label4.Text = " <==>"
        '
        'LabelAux
        '
        Me.LabelAux.AutoSize = True
        Me.LabelAux.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelAux.Location = New System.Drawing.Point(277, 119)
        Me.LabelAux.Name = "LabelAux"
        Me.LabelAux.Size = New System.Drawing.Size(21, 22)
        Me.LabelAux.TabIndex = 125
        Me.LabelAux.Text = "0"
        Me.LabelAux.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox3
        '
        Me.PictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox3.Image = Global.SynchTwinRcEngine_Interface.My.Resources.Resources.inter
        Me.PictureBox3.Location = New System.Drawing.Point(8, 91)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(51, 65)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 121
        Me.PictureBox3.TabStop = False
        '
        'ButtonAbout
        '
        Me.ButtonAbout.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.ButtonAbout.Location = New System.Drawing.Point(4, 85)
        Me.ButtonAbout.Name = "ButtonAbout"
        Me.ButtonAbout.Size = New System.Drawing.Size(25, 23)
        Me.ButtonAbout.TabIndex = 118
        Me.ButtonAbout.Text = "?"
        Me.ButtonAbout.UseVisualStyleBackColor = True
        '
        'txtMessage
        '
        Me.txtMessage.Location = New System.Drawing.Point(416, 327)
        Me.txtMessage.Name = "txtMessage"
        Me.txtMessage.Size = New System.Drawing.Size(65, 20)
        Me.txtMessage.TabIndex = 120
        '
        'btnSend
        '
        Me.btnSend.Location = New System.Drawing.Point(487, 325)
        Me.btnSend.Name = "btnSend"
        Me.btnSend.Size = New System.Drawing.Size(44, 23)
        Me.btnSend.TabIndex = 119
        Me.btnSend.Text = "Envoi"
        Me.btnSend.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.PictureBoxConnectedOK)
        Me.GroupBox2.Controls.Add(Me.Button_Connect)
        Me.GroupBox2.Controls.Add(Me.ButtonSauvegardeCOM)
        Me.GroupBox2.Controls.Add(Me.ComboBaudRate)
        Me.GroupBox2.Controls.Add(Me.ComboPort)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Location = New System.Drawing.Point(100, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(281, 76)
        Me.GroupBox2.TabIndex = 23
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Port Série"
        '
        'PictureBoxConnectedOK
        '
        Me.PictureBoxConnectedOK.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBoxConnectedOK.Location = New System.Drawing.Point(155, 17)
        Me.PictureBoxConnectedOK.Name = "PictureBoxConnectedOK"
        Me.PictureBoxConnectedOK.Size = New System.Drawing.Size(13, 16)
        Me.PictureBoxConnectedOK.TabIndex = 124
        Me.PictureBoxConnectedOK.TabStop = False
        '
        'Button_Connect
        '
        Me.Button_Connect.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button_Connect.Location = New System.Drawing.Point(169, 14)
        Me.Button_Connect.Name = "Button_Connect"
        Me.Button_Connect.Size = New System.Drawing.Size(105, 23)
        Me.Button_Connect.TabIndex = 11
        Me.Button_Connect.Text = "Connection"
        Me.Button_Connect.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.textGeneralMinMaxStopWatch)
        Me.GroupBox3.Controls.Add(Me.Label30)
        Me.GroupBox3.Controls.Add(Me.CheckBoxInversionAux)
        Me.GroupBox3.Controls.Add(Me.LabelDEBUG)
        Me.GroupBox3.Controls.Add(Me.TextBoxDEBUG)
        Me.GroupBox3.Controls.Add(Me.CheckBoxFahrenheitDegrees)
        Me.GroupBox3.Controls.Add(Me.ButtonMoteurs)
        Me.GroupBox3.Controls.Add(Me.ButtonModuleType)
        Me.GroupBox3.Controls.Add(Me.ButtonReadTempVoltage)
        Me.GroupBox3.Controls.Add(Me.PictureBoxTimer2OnOff)
        Me.GroupBox3.Controls.Add(Me.Label26)
        Me.GroupBox3.Controls.Add(Me.ButtonReadAuxiliairePulse)
        Me.GroupBox3.Controls.Add(Me.TextBoxAuxiliairePulse)
        Me.GroupBox3.Controls.Add(Me.ButtonAuxiliaireHelp)
        Me.GroupBox3.Controls.Add(Me.LabelInterType)
        Me.GroupBox3.Controls.Add(Me.txtMessage)
        Me.GroupBox3.Controls.Add(Me.ButtonMiniMaxGeneral)
        Me.GroupBox3.Controls.Add(Me.btnSend)
        Me.GroupBox3.Controls.Add(Me.ButtonDebutSynchro)
        Me.GroupBox3.Controls.Add(Me.ButtonMaxiMoteurs)
        Me.GroupBox3.Controls.Add(Me.ButtonIdleMoteur2)
        Me.GroupBox3.Controls.Add(Me.ButtonIdleMoteur1)
        Me.GroupBox3.Controls.Add(Me.ButtonReadCenter2)
        Me.GroupBox3.Controls.Add(Me.ButtonReadCenter1)
        Me.GroupBox3.Controls.Add(Me.ButtonConfigDefaut)
        Me.GroupBox3.Controls.Add(Me.ButtonPlusNombrePales)
        Me.GroupBox3.Controls.Add(Me.ButtonPlusTelemetrie)
        Me.GroupBox3.Controls.Add(Me.ButtonMoinsTelemetrie)
        Me.GroupBox3.Controls.Add(Me.ButtonMoinsNombrePales)
        Me.GroupBox3.Controls.Add(Me.ButtonPlusModeAuxiliaire)
        Me.GroupBox3.Controls.Add(Me.ButtonMoinsModeAuxiliaire)
        Me.GroupBox3.Controls.Add(Me.ButtonPlusVitesseReponse)
        Me.GroupBox3.Controls.Add(Me.ButtonMoinsVitesseReponse)
        Me.GroupBox3.Controls.Add(Me.LabelModifications)
        Me.GroupBox3.Controls.Add(Me.ButtonAnnulerModif)
        Me.GroupBox3.Controls.Add(Me.CheckBoxInversionServo2)
        Me.GroupBox3.Controls.Add(Me.CheckBoxInversionServo1)
        Me.GroupBox3.Controls.Add(Me.TextVoltageExterne)
        Me.GroupBox3.Controls.Add(Me.TextTempInterne)
        Me.GroupBox3.Controls.Add(Me.TextVoltageInterne)
        Me.GroupBox3.Controls.Add(Me.textNombrePales)
        Me.GroupBox3.Controls.Add(Me.textAddresseI2C)
        Me.GroupBox3.Controls.Add(Me.textTelemetrieType)
        Me.GroupBox3.Controls.Add(Me.textAuxiliaireMode)
        Me.GroupBox3.Controls.Add(Me.textMaxiGenerale)
        Me.GroupBox3.Controls.Add(Me.textMiniGenerale)
        Me.GroupBox3.Controls.Add(Me.textDebutSynchro)
        Me.GroupBox3.Controls.Add(Me.textMaxiMoteurs)
        Me.GroupBox3.Controls.Add(Me.textTempsReponse)
        Me.GroupBox3.Controls.Add(Me.textIdleServo2)
        Me.GroupBox3.Controls.Add(Me.textIdleServo1)
        Me.GroupBox3.Controls.Add(Me.textCentreServo2)
        Me.GroupBox3.Controls.Add(Me.textCentreServo1)
        Me.GroupBox3.Controls.Add(Me.Label20)
        Me.GroupBox3.Controls.Add(Me.Label19)
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.Label21)
        Me.GroupBox3.Controls.Add(Me.Label22)
        Me.GroupBox3.Controls.Add(Me.Label23)
        Me.GroupBox3.Controls.Add(Me.Label24)
        Me.GroupBox3.Controls.Add(Me.ButtonSauvegardeConfig)
        Me.GroupBox3.Controls.Add(Me.Label25)
        Me.GroupBox3.Location = New System.Drawing.Point(388, 3)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(537, 351)
        Me.GroupBox3.TabIndex = 26
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Configuration"
        '
        'textGeneralMinMaxStopWatch
        '
        Me.textGeneralMinMaxStopWatch.AutoSize = True
        Me.textGeneralMinMaxStopWatch.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.textGeneralMinMaxStopWatch.ForeColor = System.Drawing.Color.Red
        Me.textGeneralMinMaxStopWatch.Location = New System.Drawing.Point(205, 214)
        Me.textGeneralMinMaxStopWatch.Name = "textGeneralMinMaxStopWatch"
        Me.textGeneralMinMaxStopWatch.Size = New System.Drawing.Size(14, 13)
        Me.textGeneralMinMaxStopWatch.TabIndex = 128
        Me.textGeneralMinMaxStopWatch.Text = "0"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(414, 38)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(74, 13)
        Me.Label30.TabIndex = 127
        Me.Label30.Text = "Inversion Aux:"
        '
        'CheckBoxInversionAux
        '
        Me.CheckBoxInversionAux.AutoSize = True
        Me.CheckBoxInversionAux.Location = New System.Drawing.Point(490, 37)
        Me.CheckBoxInversionAux.Name = "CheckBoxInversionAux"
        Me.CheckBoxInversionAux.Size = New System.Drawing.Size(46, 17)
        Me.CheckBoxInversionAux.TabIndex = 126
        Me.CheckBoxInversionAux.Text = "Non"
        Me.CheckBoxInversionAux.UseVisualStyleBackColor = True
        '
        'LabelDEBUG
        '
        Me.LabelDEBUG.AutoSize = True
        Me.LabelDEBUG.Location = New System.Drawing.Point(6, 330)
        Me.LabelDEBUG.Name = "LabelDEBUG"
        Me.LabelDEBUG.Size = New System.Drawing.Size(51, 13)
        Me.LabelDEBUG.TabIndex = 125
        Me.LabelDEBUG.Text = "DEBUG :"
        '
        'TextBoxDEBUG
        '
        Me.TextBoxDEBUG.Location = New System.Drawing.Point(63, 327)
        Me.TextBoxDEBUG.Name = "TextBoxDEBUG"
        Me.TextBoxDEBUG.Size = New System.Drawing.Size(347, 20)
        Me.TextBoxDEBUG.TabIndex = 124
        Me.TextBoxDEBUG.Text = "-"
        '
        'CheckBoxFahrenheitDegrees
        '
        Me.CheckBoxFahrenheitDegrees.AutoSize = True
        Me.CheckBoxFahrenheitDegrees.Location = New System.Drawing.Point(491, 171)
        Me.CheckBoxFahrenheitDegrees.Name = "CheckBoxFahrenheitDegrees"
        Me.CheckBoxFahrenheitDegrees.Size = New System.Drawing.Size(36, 17)
        Me.CheckBoxFahrenheitDegrees.TabIndex = 123
        Me.CheckBoxFahrenheitDegrees.Text = "°F"
        Me.CheckBoxFahrenheitDegrees.UseVisualStyleBackColor = True
        '
        'ButtonMoteurs
        '
        Me.ButtonMoteurs.Location = New System.Drawing.Point(459, 300)
        Me.ButtonMoteurs.Name = "ButtonMoteurs"
        Me.ButtonMoteurs.Size = New System.Drawing.Size(72, 23)
        Me.ButtonMoteurs.TabIndex = 117
        Me.ButtonMoteurs.Text = "Moteurs >>"
        Me.ButtonMoteurs.UseVisualStyleBackColor = True
        '
        'ButtonModuleType
        '
        Me.ButtonModuleType.Enabled = False
        Me.ButtonModuleType.Location = New System.Drawing.Point(457, 254)
        Me.ButtonModuleType.Name = "ButtonModuleType"
        Me.ButtonModuleType.Size = New System.Drawing.Size(74, 20)
        Me.ButtonModuleType.TabIndex = 120
        Me.ButtonModuleType.Text = "Maître"
        Me.ButtonModuleType.UseVisualStyleBackColor = True
        '
        'ButtonReadTempVoltage
        '
        Me.ButtonReadTempVoltage.Location = New System.Drawing.Point(487, 190)
        Me.ButtonReadTempVoltage.Name = "ButtonReadTempVoltage"
        Me.ButtonReadTempVoltage.Size = New System.Drawing.Size(44, 20)
        Me.ButtonReadTempVoltage.TabIndex = 122
        Me.ButtonReadTempVoltage.Text = "Lire"
        Me.ButtonReadTempVoltage.UseVisualStyleBackColor = True
        '
        'PictureBoxTimer2OnOff
        '
        Me.PictureBoxTimer2OnOff.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBoxTimer2OnOff.Location = New System.Drawing.Point(254, 256)
        Me.PictureBoxTimer2OnOff.Name = "PictureBoxTimer2OnOff"
        Me.PictureBoxTimer2OnOff.Size = New System.Drawing.Size(13, 16)
        Me.PictureBoxTimer2OnOff.TabIndex = 121
        Me.PictureBoxTimer2OnOff.TabStop = False
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(24, 257)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(91, 13)
        Me.Label26.TabIndex = 120
        Me.Label26.Text = "Position Auxiliaire:"
        '
        'ButtonReadAuxiliairePulse
        '
        Me.ButtonReadAuxiliairePulse.Location = New System.Drawing.Point(205, 254)
        Me.ButtonReadAuxiliairePulse.Name = "ButtonReadAuxiliairePulse"
        Me.ButtonReadAuxiliairePulse.Size = New System.Drawing.Size(44, 20)
        Me.ButtonReadAuxiliairePulse.TabIndex = 119
        Me.ButtonReadAuxiliairePulse.Text = "Lire"
        Me.ButtonReadAuxiliairePulse.UseVisualStyleBackColor = True
        '
        'TextBoxAuxiliairePulse
        '
        Me.TextBoxAuxiliairePulse.Location = New System.Drawing.Point(157, 255)
        Me.TextBoxAuxiliairePulse.Name = "TextBoxAuxiliairePulse"
        Me.TextBoxAuxiliairePulse.Size = New System.Drawing.Size(42, 20)
        Me.TextBoxAuxiliairePulse.TabIndex = 118
        Me.TextBoxAuxiliairePulse.Text = "0"
        '
        'ButtonAuxiliaireHelp
        '
        Me.ButtonAuxiliaireHelp.Location = New System.Drawing.Point(4, 233)
        Me.ButtonAuxiliaireHelp.Name = "ButtonAuxiliaireHelp"
        Me.ButtonAuxiliaireHelp.Size = New System.Drawing.Size(19, 20)
        Me.ButtonAuxiliaireHelp.TabIndex = 117
        Me.ButtonAuxiliaireHelp.Text = "?"
        Me.ButtonAuxiliaireHelp.UseVisualStyleBackColor = True
        '
        'LabelInterType
        '
        Me.LabelInterType.AutoSize = True
        Me.LabelInterType.Location = New System.Drawing.Point(255, 237)
        Me.LabelInterType.Name = "LabelInterType"
        Me.LabelInterType.Size = New System.Drawing.Size(88, 13)
        Me.LabelInterType.TabIndex = 112
        Me.LabelInterType.Text = " ===> Non Utilisé"
        '
        'ButtonMiniMaxGeneral
        '
        Me.ButtonMiniMaxGeneral.Location = New System.Drawing.Point(205, 189)
        Me.ButtonMiniMaxGeneral.Name = "ButtonMiniMaxGeneral"
        Me.ButtonMiniMaxGeneral.Size = New System.Drawing.Size(44, 20)
        Me.ButtonMiniMaxGeneral.TabIndex = 110
        Me.ButtonMiniMaxGeneral.Text = "Lire"
        Me.ButtonMiniMaxGeneral.UseVisualStyleBackColor = True
        '
        'ButtonDebutSynchro
        '
        Me.ButtonDebutSynchro.Location = New System.Drawing.Point(205, 167)
        Me.ButtonDebutSynchro.Name = "ButtonDebutSynchro"
        Me.ButtonDebutSynchro.Size = New System.Drawing.Size(44, 20)
        Me.ButtonDebutSynchro.TabIndex = 109
        Me.ButtonDebutSynchro.Text = "Lire"
        Me.ButtonDebutSynchro.UseVisualStyleBackColor = True
        '
        'ButtonMaxiMoteurs
        '
        Me.ButtonMaxiMoteurs.Location = New System.Drawing.Point(205, 145)
        Me.ButtonMaxiMoteurs.Name = "ButtonMaxiMoteurs"
        Me.ButtonMaxiMoteurs.Size = New System.Drawing.Size(44, 20)
        Me.ButtonMaxiMoteurs.TabIndex = 108
        Me.ButtonMaxiMoteurs.Text = "Lire"
        Me.ButtonMaxiMoteurs.UseVisualStyleBackColor = True
        '
        'ButtonIdleMoteur2
        '
        Me.ButtonIdleMoteur2.Location = New System.Drawing.Point(205, 101)
        Me.ButtonIdleMoteur2.Name = "ButtonIdleMoteur2"
        Me.ButtonIdleMoteur2.Size = New System.Drawing.Size(44, 20)
        Me.ButtonIdleMoteur2.TabIndex = 107
        Me.ButtonIdleMoteur2.Text = "Lire"
        Me.ButtonIdleMoteur2.UseVisualStyleBackColor = True
        '
        'ButtonIdleMoteur1
        '
        Me.ButtonIdleMoteur1.Location = New System.Drawing.Point(205, 79)
        Me.ButtonIdleMoteur1.Name = "ButtonIdleMoteur1"
        Me.ButtonIdleMoteur1.Size = New System.Drawing.Size(44, 20)
        Me.ButtonIdleMoteur1.TabIndex = 106
        Me.ButtonIdleMoteur1.Text = "Lire"
        Me.ButtonIdleMoteur1.UseVisualStyleBackColor = True
        '
        'ButtonReadCenter2
        '
        Me.ButtonReadCenter2.Location = New System.Drawing.Point(205, 56)
        Me.ButtonReadCenter2.Name = "ButtonReadCenter2"
        Me.ButtonReadCenter2.Size = New System.Drawing.Size(44, 20)
        Me.ButtonReadCenter2.TabIndex = 105
        Me.ButtonReadCenter2.Text = "Lire"
        Me.ButtonReadCenter2.UseVisualStyleBackColor = True
        '
        'ButtonReadCenter1
        '
        Me.ButtonReadCenter1.Location = New System.Drawing.Point(205, 34)
        Me.ButtonReadCenter1.Name = "ButtonReadCenter1"
        Me.ButtonReadCenter1.Size = New System.Drawing.Size(44, 20)
        Me.ButtonReadCenter1.TabIndex = 19
        Me.ButtonReadCenter1.Text = "Lire"
        Me.ButtonReadCenter1.UseVisualStyleBackColor = True
        '
        'ButtonConfigDefaut
        '
        Me.ButtonConfigDefaut.Location = New System.Drawing.Point(158, 300)
        Me.ButtonConfigDefaut.Name = "ButtonConfigDefaut"
        Me.ButtonConfigDefaut.Size = New System.Drawing.Size(128, 23)
        Me.ButtonConfigDefaut.TabIndex = 104
        Me.ButtonConfigDefaut.Text = "RAZ Congiguration"
        Me.ButtonConfigDefaut.UseVisualStyleBackColor = True
        '
        'ButtonPlusNombrePales
        '
        Me.ButtonPlusNombrePales.Location = New System.Drawing.Point(502, 122)
        Me.ButtonPlusNombrePales.Name = "ButtonPlusNombrePales"
        Me.ButtonPlusNombrePales.Size = New System.Drawing.Size(19, 20)
        Me.ButtonPlusNombrePales.TabIndex = 103
        Me.ButtonPlusNombrePales.Text = "+"
        Me.ButtonPlusNombrePales.UseVisualStyleBackColor = True
        '
        'ButtonPlusTelemetrie
        '
        Me.ButtonPlusTelemetrie.Enabled = False
        Me.ButtonPlusTelemetrie.Location = New System.Drawing.Point(502, 78)
        Me.ButtonPlusTelemetrie.Name = "ButtonPlusTelemetrie"
        Me.ButtonPlusTelemetrie.Size = New System.Drawing.Size(19, 20)
        Me.ButtonPlusTelemetrie.TabIndex = 102
        Me.ButtonPlusTelemetrie.Text = "+"
        Me.ButtonPlusTelemetrie.UseVisualStyleBackColor = True
        '
        'ButtonMoinsTelemetrie
        '
        Me.ButtonMoinsTelemetrie.Enabled = False
        Me.ButtonMoinsTelemetrie.Location = New System.Drawing.Point(477, 78)
        Me.ButtonMoinsTelemetrie.Name = "ButtonMoinsTelemetrie"
        Me.ButtonMoinsTelemetrie.Size = New System.Drawing.Size(19, 20)
        Me.ButtonMoinsTelemetrie.TabIndex = 101
        Me.ButtonMoinsTelemetrie.Text = "-"
        Me.ButtonMoinsTelemetrie.UseVisualStyleBackColor = True
        '
        'ButtonMoinsNombrePales
        '
        Me.ButtonMoinsNombrePales.Location = New System.Drawing.Point(477, 122)
        Me.ButtonMoinsNombrePales.Name = "ButtonMoinsNombrePales"
        Me.ButtonMoinsNombrePales.Size = New System.Drawing.Size(19, 20)
        Me.ButtonMoinsNombrePales.TabIndex = 100
        Me.ButtonMoinsNombrePales.Text = "-"
        Me.ButtonMoinsNombrePales.UseVisualStyleBackColor = True
        '
        'ButtonPlusModeAuxiliaire
        '
        Me.ButtonPlusModeAuxiliaire.Location = New System.Drawing.Point(230, 232)
        Me.ButtonPlusModeAuxiliaire.Name = "ButtonPlusModeAuxiliaire"
        Me.ButtonPlusModeAuxiliaire.Size = New System.Drawing.Size(19, 20)
        Me.ButtonPlusModeAuxiliaire.TabIndex = 99
        Me.ButtonPlusModeAuxiliaire.Text = "+"
        Me.ButtonPlusModeAuxiliaire.UseVisualStyleBackColor = True
        '
        'ButtonMoinsModeAuxiliaire
        '
        Me.ButtonMoinsModeAuxiliaire.Location = New System.Drawing.Point(205, 232)
        Me.ButtonMoinsModeAuxiliaire.Name = "ButtonMoinsModeAuxiliaire"
        Me.ButtonMoinsModeAuxiliaire.Size = New System.Drawing.Size(19, 20)
        Me.ButtonMoinsModeAuxiliaire.TabIndex = 98
        Me.ButtonMoinsModeAuxiliaire.Text = "-"
        Me.ButtonMoinsModeAuxiliaire.UseVisualStyleBackColor = True
        '
        'ButtonPlusVitesseReponse
        '
        Me.ButtonPlusVitesseReponse.Location = New System.Drawing.Point(230, 122)
        Me.ButtonPlusVitesseReponse.Name = "ButtonPlusVitesseReponse"
        Me.ButtonPlusVitesseReponse.Size = New System.Drawing.Size(19, 20)
        Me.ButtonPlusVitesseReponse.TabIndex = 97
        Me.ButtonPlusVitesseReponse.Text = "+"
        Me.ButtonPlusVitesseReponse.UseVisualStyleBackColor = True
        '
        'ButtonMoinsVitesseReponse
        '
        Me.ButtonMoinsVitesseReponse.Location = New System.Drawing.Point(205, 122)
        Me.ButtonMoinsVitesseReponse.Name = "ButtonMoinsVitesseReponse"
        Me.ButtonMoinsVitesseReponse.Size = New System.Drawing.Size(19, 20)
        Me.ButtonMoinsVitesseReponse.TabIndex = 96
        Me.ButtonMoinsVitesseReponse.Text = "-"
        Me.ButtonMoinsVitesseReponse.UseVisualStyleBackColor = True
        '
        'LabelModifications
        '
        Me.LabelModifications.AutoSize = True
        Me.LabelModifications.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelModifications.Enabled = False
        Me.LabelModifications.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelModifications.ForeColor = System.Drawing.Color.Red
        Me.LabelModifications.Location = New System.Drawing.Point(120, 278)
        Me.LabelModifications.MaximumSize = New System.Drawing.Size(300, 0)
        Me.LabelModifications.MinimumSize = New System.Drawing.Size(300, 0)
        Me.LabelModifications.Name = "LabelModifications"
        Me.LabelModifications.Size = New System.Drawing.Size(300, 19)
        Me.LabelModifications.TabIndex = 95
        Me.LabelModifications.Text = "..."
        Me.LabelModifications.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'ButtonAnnulerModif
        '
        Me.ButtonAnnulerModif.Location = New System.Drawing.Point(7, 300)
        Me.ButtonAnnulerModif.Name = "ButtonAnnulerModif"
        Me.ButtonAnnulerModif.Size = New System.Drawing.Size(128, 23)
        Me.ButtonAnnulerModif.TabIndex = 94
        Me.ButtonAnnulerModif.Text = "Annuler modifications"
        Me.ButtonAnnulerModif.UseVisualStyleBackColor = True
        '
        'CheckBoxInversionServo2
        '
        Me.CheckBoxInversionServo2.AutoSize = True
        Me.CheckBoxInversionServo2.Location = New System.Drawing.Point(358, 58)
        Me.CheckBoxInversionServo2.Name = "CheckBoxInversionServo2"
        Me.CheckBoxInversionServo2.Size = New System.Drawing.Size(46, 17)
        Me.CheckBoxInversionServo2.TabIndex = 93
        Me.CheckBoxInversionServo2.Text = "Non"
        Me.CheckBoxInversionServo2.UseVisualStyleBackColor = True
        '
        'CheckBoxInversionServo1
        '
        Me.CheckBoxInversionServo1.AutoSize = True
        Me.CheckBoxInversionServo1.Location = New System.Drawing.Point(358, 36)
        Me.CheckBoxInversionServo1.Name = "CheckBoxInversionServo1"
        Me.CheckBoxInversionServo1.Size = New System.Drawing.Size(46, 17)
        Me.CheckBoxInversionServo1.TabIndex = 92
        Me.CheckBoxInversionServo1.Text = "Non"
        Me.CheckBoxInversionServo1.UseVisualStyleBackColor = True
        '
        'TextVoltageExterne
        '
        Me.TextVoltageExterne.Location = New System.Drawing.Point(426, 190)
        Me.TextVoltageExterne.Name = "TextVoltageExterne"
        Me.TextVoltageExterne.Size = New System.Drawing.Size(46, 20)
        Me.TextVoltageExterne.TabIndex = 91
        Me.TextVoltageExterne.Text = "0 v"
        '
        'TextTempInterne
        '
        Me.TextTempInterne.Location = New System.Drawing.Point(426, 168)
        Me.TextTempInterne.Name = "TextTempInterne"
        Me.TextTempInterne.Size = New System.Drawing.Size(46, 20)
        Me.TextTempInterne.TabIndex = 90
        Me.TextTempInterne.Text = "0 °C"
        '
        'TextVoltageInterne
        '
        Me.TextVoltageInterne.Location = New System.Drawing.Point(426, 146)
        Me.TextVoltageInterne.Name = "TextVoltageInterne"
        Me.TextVoltageInterne.Size = New System.Drawing.Size(46, 20)
        Me.TextVoltageInterne.TabIndex = 89
        Me.TextVoltageInterne.Text = "0 v"
        '
        'textNombrePales
        '
        Me.textNombrePales.Location = New System.Drawing.Point(426, 123)
        Me.textNombrePales.Name = "textNombrePales"
        Me.textNombrePales.Size = New System.Drawing.Size(46, 20)
        Me.textNombrePales.TabIndex = 87
        Me.textNombrePales.Text = "0"
        '
        'textAddresseI2C
        '
        Me.textAddresseI2C.Location = New System.Drawing.Point(426, 101)
        Me.textAddresseI2C.Name = "textAddresseI2C"
        Me.textAddresseI2C.Size = New System.Drawing.Size(46, 20)
        Me.textAddresseI2C.TabIndex = 86
        Me.textAddresseI2C.Text = "0"
        '
        'textTelemetrieType
        '
        Me.textTelemetrieType.Enabled = False
        Me.textTelemetrieType.Location = New System.Drawing.Point(426, 79)
        Me.textTelemetrieType.Name = "textTelemetrieType"
        Me.textTelemetrieType.Size = New System.Drawing.Size(46, 20)
        Me.textTelemetrieType.TabIndex = 85
        Me.textTelemetrieType.Text = "0"
        '
        'textAuxiliaireMode
        '
        Me.textAuxiliaireMode.Location = New System.Drawing.Point(157, 233)
        Me.textAuxiliaireMode.Name = "textAuxiliaireMode"
        Me.textAuxiliaireMode.Size = New System.Drawing.Size(42, 20)
        Me.textAuxiliaireMode.TabIndex = 84
        Me.textAuxiliaireMode.Text = "0"
        '
        'textMaxiGenerale
        '
        Me.textMaxiGenerale.Location = New System.Drawing.Point(157, 211)
        Me.textMaxiGenerale.Name = "textMaxiGenerale"
        Me.textMaxiGenerale.Size = New System.Drawing.Size(42, 20)
        Me.textMaxiGenerale.TabIndex = 83
        Me.textMaxiGenerale.Text = "0"
        '
        'textMiniGenerale
        '
        Me.textMiniGenerale.Location = New System.Drawing.Point(157, 189)
        Me.textMiniGenerale.Name = "textMiniGenerale"
        Me.textMiniGenerale.Size = New System.Drawing.Size(42, 20)
        Me.textMiniGenerale.TabIndex = 82
        Me.textMiniGenerale.Text = "0"
        '
        'textDebutSynchro
        '
        Me.textDebutSynchro.Location = New System.Drawing.Point(157, 167)
        Me.textDebutSynchro.Name = "textDebutSynchro"
        Me.textDebutSynchro.Size = New System.Drawing.Size(42, 20)
        Me.textDebutSynchro.TabIndex = 81
        Me.textDebutSynchro.Text = "0"
        '
        'textMaxiMoteurs
        '
        Me.textMaxiMoteurs.Location = New System.Drawing.Point(157, 145)
        Me.textMaxiMoteurs.Name = "textMaxiMoteurs"
        Me.textMaxiMoteurs.Size = New System.Drawing.Size(42, 20)
        Me.textMaxiMoteurs.TabIndex = 80
        Me.textMaxiMoteurs.Text = "0"
        '
        'textTempsReponse
        '
        Me.textTempsReponse.Location = New System.Drawing.Point(157, 123)
        Me.textTempsReponse.Name = "textTempsReponse"
        Me.textTempsReponse.Size = New System.Drawing.Size(42, 20)
        Me.textTempsReponse.TabIndex = 79
        Me.textTempsReponse.Text = "0"
        '
        'textIdleServo2
        '
        Me.textIdleServo2.Location = New System.Drawing.Point(157, 101)
        Me.textIdleServo2.Name = "textIdleServo2"
        Me.textIdleServo2.Size = New System.Drawing.Size(42, 20)
        Me.textIdleServo2.TabIndex = 78
        Me.textIdleServo2.Text = "0"
        '
        'textIdleServo1
        '
        Me.textIdleServo1.Location = New System.Drawing.Point(157, 79)
        Me.textIdleServo1.Name = "textIdleServo1"
        Me.textIdleServo1.Size = New System.Drawing.Size(42, 20)
        Me.textIdleServo1.TabIndex = 77
        Me.textIdleServo1.Text = "0"
        '
        'textCentreServo2
        '
        Me.textCentreServo2.Location = New System.Drawing.Point(157, 56)
        Me.textCentreServo2.Name = "textCentreServo2"
        Me.textCentreServo2.Size = New System.Drawing.Size(42, 20)
        Me.textCentreServo2.TabIndex = 76
        Me.textCentreServo2.Text = "0"
        '
        'textCentreServo1
        '
        Me.textCentreServo1.Location = New System.Drawing.Point(157, 34)
        Me.textCentreServo1.Name = "textCentreServo1"
        Me.textCentreServo1.Size = New System.Drawing.Size(42, 20)
        Me.textCentreServo1.TabIndex = 75
        Me.textCentreServo1.Text = "0"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(268, 193)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(87, 13)
        Me.Label20.TabIndex = 74
        Me.Label20.Text = "Voltage externe :"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(268, 171)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(108, 13)
        Me.Label19.TabIndex = 73
        Me.Label19.Text = "Temperature interne :"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(268, 149)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(84, 13)
        Me.Label18.TabIndex = 72
        Me.Label18.Text = "Voltage interne :"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(268, 126)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(152, 13)
        Me.Label16.TabIndex = 70
        Me.Label16.Text = "Nombre de pales ou d'aimants:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(268, 104)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(91, 13)
        Me.Label15.TabIndex = 69
        Me.Label15.Text = "Adresse I2C LCD:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Enabled = False
        Me.Label14.Location = New System.Drawing.Point(268, 82)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(93, 13)
        Me.Label14.TabIndex = 68
        Me.Label14.Text = "Telemetry version:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(268, 59)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(88, 13)
        Me.Label13.TabIndex = 67
        Me.Label13.Text = "Inversion servo2:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(268, 37)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(88, 13)
        Me.Label12.TabIndex = 66
        Me.Label12.Text = "Inversion servo1:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(23, 236)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(130, 13)
        Me.Label11.TabIndex = 65
        Me.Label11.Text = "Connexion Ch AUX: mode"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(23, 214)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(115, 13)
        Me.Label10.TabIndex = 64
        Me.Label10.Text = "Position maxi generale:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(23, 192)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(112, 13)
        Me.Label9.TabIndex = 63
        Me.Label9.Text = "Position mini generale:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(23, 170)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(113, 13)
        Me.Label8.TabIndex = 62
        Me.Label8.Text = "Début synchro servos:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(23, 148)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(105, 13)
        Me.Label7.TabIndex = 61
        Me.Label7.Text = "Position maxi servos:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(23, 126)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(100, 13)
        Me.Label6.TabIndex = 60
        Me.Label6.Text = "Vitesse de reponse:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(23, 104)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(110, 13)
        Me.Label21.TabIndex = 59
        Me.Label21.Text = "Position Idle servos 2:"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(23, 82)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(110, 13)
        Me.Label22.TabIndex = 58
        Me.Label22.Text = "Position Idle servos 1:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(22, 59)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(79, 13)
        Me.Label23.TabIndex = 57
        Me.Label23.Text = "Centre servo2: "
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(23, 37)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(79, 13)
        Me.Label24.TabIndex = 56
        Me.Label24.Text = "Centre servo1: "
        '
        'ButtonSauvegardeConfig
        '
        Me.ButtonSauvegardeConfig.Location = New System.Drawing.Point(309, 300)
        Me.ButtonSauvegardeConfig.Name = "ButtonSauvegardeConfig"
        Me.ButtonSauvegardeConfig.Size = New System.Drawing.Size(128, 23)
        Me.ButtonSauvegardeConfig.TabIndex = 55
        Me.ButtonSauvegardeConfig.Text = "Sauver Configuration"
        Me.ButtonSauvegardeConfig.UseVisualStyleBackColor = True
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(148, 10)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(286, 17)
        Me.Label25.TabIndex = 54
        Me.Label25.Text = "Editeur de la configuration du module:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(218, 23)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(24, 16)
        Me.Label17.TabIndex = 136
        Me.Label17.Text = "V1"
        '
        'PictureBoxTimer1OnOff
        '
        Me.PictureBoxTimer1OnOff.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBoxTimer1OnOff.Location = New System.Drawing.Point(247, 15)
        Me.PictureBoxTimer1OnOff.Name = "PictureBoxTimer1OnOff"
        Me.PictureBoxTimer1OnOff.Size = New System.Drawing.Size(13, 16)
        Me.PictureBoxTimer1OnOff.TabIndex = 116
        Me.PictureBoxTimer1OnOff.TabStop = False
        '
        'ButtonReadSpeeds
        '
        Me.ButtonReadSpeeds.Location = New System.Drawing.Point(191, 11)
        Me.ButtonReadSpeeds.Name = "ButtonReadSpeeds"
        Me.ButtonReadSpeeds.Size = New System.Drawing.Size(54, 23)
        Me.ButtonReadSpeeds.TabIndex = 115
        Me.ButtonReadSpeeds.Text = "Vitesse"
        Me.ButtonReadSpeeds.UseVisualStyleBackColor = True
        '
        'TimerSpeeds
        '
        Me.TimerSpeeds.Interval = 500
        '
        'TimerRXAuxiliaire
        '
        Me.TimerRXAuxiliaire.Interval = 1000
        '
        'TimerRXMotors
        '
        Me.TimerRXMotors.Interval = 1000
        '
        'TimerHardwareInfos
        '
        Me.TimerHardwareInfos.Interval = 1000
        '
        'Moteurs
        '
        Me.Moteurs.Controls.Add(Me.GroupBox4)
        Me.Moteurs.Controls.Add(Me.ProgressBarThrottleMotors)
        Me.Moteurs.Controls.Add(Me.ButtonDataLogger)
        Me.Moteurs.Controls.Add(Me.Label28)
        Me.Moteurs.Controls.Add(Me.Label27)
        Me.Moteurs.Controls.Add(Me.AquaGaugeMoteur2)
        Me.Moteurs.Controls.Add(Me.AquaGaugeMoteur1)
        Me.Moteurs.Controls.Add(Me.LabelVitesse1)
        Me.Moteurs.Controls.Add(Me.LabelVitesse2)
        Me.Moteurs.Controls.Add(Me.ButtonReadSpeeds)
        Me.Moteurs.Controls.Add(Me.PictureBoxTimer1OnOff)
        Me.Moteurs.Location = New System.Drawing.Point(931, 3)
        Me.Moteurs.Name = "Moteurs"
        Me.Moteurs.Size = New System.Drawing.Size(438, 351)
        Me.Moteurs.TabIndex = 117
        Me.Moteurs.TabStop = False
        Me.Moteurs.Text = "Moteurs"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label31)
        Me.GroupBox4.Controls.Add(Me.Label5)
        Me.GroupBox4.Controls.Add(Me.Label17)
        Me.GroupBox4.Controls.Add(Me.TextBoxForceSpeedSimu2)
        Me.GroupBox4.Controls.Add(Me.TrackBarSpeedSimu2)
        Me.GroupBox4.Controls.Add(Me.TrackBarSpeedSimu1)
        Me.GroupBox4.Controls.Add(Me.ButtonDiffSpeedSimuConsigne)
        Me.GroupBox4.Controls.Add(Me.Label29)
        Me.GroupBox4.Controls.Add(Me.TextBoxDiffSpeedSimuConsigne)
        Me.GroupBox4.Controls.Add(Me.TextBoxForceSpeedSimu1)
        Me.GroupBox4.Controls.Add(Me.ButtonSpeedSimuOn)
        Me.GroupBox4.Location = New System.Drawing.Point(6, 254)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(393, 91)
        Me.GroupBox4.TabIndex = 128
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Simulation Vitesse"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(7, 69)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(155, 15)
        Me.Label31.TabIndex = 128
        Me.Label31.Text = "Synchroniser Vitesses :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(217, 55)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(24, 16)
        Me.Label5.TabIndex = 139
        Me.Label5.Text = "V2"
        '
        'TextBoxForceSpeedSimu2
        '
        Me.TextBoxForceSpeedSimu2.Location = New System.Drawing.Point(146, 19)
        Me.TextBoxForceSpeedSimu2.Name = "TextBoxForceSpeedSimu2"
        Me.TextBoxForceSpeedSimu2.Size = New System.Drawing.Size(40, 20)
        Me.TextBoxForceSpeedSimu2.TabIndex = 138
        Me.TextBoxForceSpeedSimu2.Text = "5000"
        Me.TextBoxForceSpeedSimu2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TrackBarSpeedSimu2
        '
        Me.TrackBarSpeedSimu2.LargeChange = 10
        Me.TrackBarSpeedSimu2.Location = New System.Drawing.Point(241, 43)
        Me.TrackBarSpeedSimu2.Maximum = 20000
        Me.TrackBarSpeedSimu2.Minimum = 500
        Me.TrackBarSpeedSimu2.Name = "TrackBarSpeedSimu2"
        Me.TrackBarSpeedSimu2.Size = New System.Drawing.Size(146, 45)
        Me.TrackBarSpeedSimu2.SmallChange = 10
        Me.TrackBarSpeedSimu2.TabIndex = 137
        Me.TrackBarSpeedSimu2.TickFrequency = 1000
        Me.TrackBarSpeedSimu2.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        Me.TrackBarSpeedSimu2.Value = 500
        '
        'TrackBarSpeedSimu1
        '
        Me.TrackBarSpeedSimu1.LargeChange = 10
        Me.TrackBarSpeedSimu1.Location = New System.Drawing.Point(241, 10)
        Me.TrackBarSpeedSimu1.Maximum = 20000
        Me.TrackBarSpeedSimu1.Minimum = 500
        Me.TrackBarSpeedSimu1.Name = "TrackBarSpeedSimu1"
        Me.TrackBarSpeedSimu1.Size = New System.Drawing.Size(146, 45)
        Me.TrackBarSpeedSimu1.SmallChange = 10
        Me.TrackBarSpeedSimu1.TabIndex = 136
        Me.TrackBarSpeedSimu1.TickFrequency = 1000
        Me.TrackBarSpeedSimu1.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        Me.TrackBarSpeedSimu1.Value = 500
        '
        'ButtonDiffSpeedSimuConsigne
        '
        Me.ButtonDiffSpeedSimuConsigne.Location = New System.Drawing.Point(10, 43)
        Me.ButtonDiffSpeedSimuConsigne.Name = "ButtonDiffSpeedSimuConsigne"
        Me.ButtonDiffSpeedSimuConsigne.Size = New System.Drawing.Size(87, 22)
        Me.ButtonDiffSpeedSimuConsigne.TabIndex = 131
        Me.ButtonDiffSpeedSimuConsigne.Text = "Diff Vitesse OK"
        Me.ButtonDiffSpeedSimuConsigne.UseVisualStyleBackColor = True
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(143, 47)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(32, 13)
        Me.Label29.TabIndex = 130
        Me.Label29.Text = "tr/mn"
        '
        'TextBoxDiffSpeedSimuConsigne
        '
        Me.TextBoxDiffSpeedSimuConsigne.Location = New System.Drawing.Point(106, 43)
        Me.TextBoxDiffSpeedSimuConsigne.Name = "TextBoxDiffSpeedSimuConsigne"
        Me.TextBoxDiffSpeedSimuConsigne.Size = New System.Drawing.Size(34, 20)
        Me.TextBoxDiffSpeedSimuConsigne.TabIndex = 128
        Me.TextBoxDiffSpeedSimuConsigne.Text = "100"
        Me.TextBoxDiffSpeedSimuConsigne.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBoxForceSpeedSimu1
        '
        Me.TextBoxForceSpeedSimu1.Location = New System.Drawing.Point(100, 19)
        Me.TextBoxForceSpeedSimu1.Name = "TextBoxForceSpeedSimu1"
        Me.TextBoxForceSpeedSimu1.Size = New System.Drawing.Size(40, 20)
        Me.TextBoxForceSpeedSimu1.TabIndex = 124
        Me.TextBoxForceSpeedSimu1.Text = "5000"
        Me.TextBoxForceSpeedSimu1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ButtonSpeedSimuOn
        '
        Me.ButtonSpeedSimuOn.Location = New System.Drawing.Point(10, 18)
        Me.ButtonSpeedSimuOn.Name = "ButtonSpeedSimuOn"
        Me.ButtonSpeedSimuOn.Size = New System.Drawing.Size(87, 22)
        Me.ButtonSpeedSimuOn.TabIndex = 127
        Me.ButtonSpeedSimuOn.Text = "Simu Vitesse"
        Me.ButtonSpeedSimuOn.UseVisualStyleBackColor = True
        '
        'ButtonDataLogger
        '
        Me.ButtonDataLogger.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.ButtonDataLogger.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.ButtonDataLogger.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonDataLogger.ForeColor = System.Drawing.Color.Green
        Me.ButtonDataLogger.Location = New System.Drawing.Point(407, 261)
        Me.ButtonDataLogger.Name = "ButtonDataLogger"
        Me.ButtonDataLogger.Size = New System.Drawing.Size(25, 81)
        Me.ButtonDataLogger.TabIndex = 123
        Me.ButtonDataLogger.Text = "DATA"
        Me.ButtonDataLogger.UseVisualStyleBackColor = True
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(268, 14)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(72, 17)
        Me.Label28.TabIndex = 124
        Me.Label28.Text = "Moteur 2"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(71, 14)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(72, 17)
        Me.Label27.TabIndex = 123
        Me.Label27.Text = "Moteur 1"
        '
        'AquaGaugeMoteur2
        '
        Me.AquaGaugeMoteur2.BackColor = System.Drawing.Color.Transparent
        Me.AquaGaugeMoteur2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.AquaGaugeMoteur2.DecimalPlaces = 0
        Me.AquaGaugeMoteur2.DialAlpha = 255
        Me.AquaGaugeMoteur2.DialBorderColor = System.Drawing.Color.Gray
        Me.AquaGaugeMoteur2.DialColor = System.Drawing.Color.Black
        Me.AquaGaugeMoteur2.DialText = Nothing
        Me.AquaGaugeMoteur2.DialTextColor = System.Drawing.Color.Gold
        Me.AquaGaugeMoteur2.DialTextFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AquaGaugeMoteur2.DialTextVOffset = 0
        Me.AquaGaugeMoteur2.DigitalValue = 0.0!
        Me.AquaGaugeMoteur2.DigitalValueBackAlpha = 1
        Me.AquaGaugeMoteur2.DigitalValueBackColor = System.Drawing.Color.White
        Me.AquaGaugeMoteur2.DigitalValueColor = System.Drawing.Color.Orange
        Me.AquaGaugeMoteur2.DigitalValueDecimalPlaces = 0
        Me.AquaGaugeMoteur2.Glossiness = 40.0!
        Me.AquaGaugeMoteur2.Location = New System.Drawing.Point(239, 37)
        Me.AquaGaugeMoteur2.MaxValue = 20000.0!
        Me.AquaGaugeMoteur2.MinValue = 0.0!
        Me.AquaGaugeMoteur2.Name = "AquaGaugeMoteur2"
        Me.AquaGaugeMoteur2.NoOfSubDivisions = 1
        Me.AquaGaugeMoteur2.PointerColor = System.Drawing.Color.Black
        Me.AquaGaugeMoteur2.RimAlpha = 255
        Me.AquaGaugeMoteur2.RimColor = System.Drawing.Color.Gold
        Me.AquaGaugeMoteur2.ScaleColor = System.Drawing.Color.Gold
        Me.AquaGaugeMoteur2.ScaleFontSizeDivider = 25
        Me.AquaGaugeMoteur2.Size = New System.Drawing.Size(195, 195)
        Me.AquaGaugeMoteur2.TabIndex = 118
        Me.AquaGaugeMoteur2.Threshold1Color = System.Drawing.Color.LawnGreen
        Me.AquaGaugeMoteur2.Threshold1Start = 0.0!
        Me.AquaGaugeMoteur2.Threshold1Stop = 2000.0!
        Me.AquaGaugeMoteur2.Threshold2Color = System.Drawing.Color.Red
        Me.AquaGaugeMoteur2.Threshold2Start = 16000.0!
        Me.AquaGaugeMoteur2.Threshold2Stop = 20000.0!
        Me.AquaGaugeMoteur2.Value = 0.0!
        Me.AquaGaugeMoteur2.ValueToDigital = True
        '
        'AquaGaugeMoteur1
        '
        Me.AquaGaugeMoteur1.BackColor = System.Drawing.Color.Transparent
        Me.AquaGaugeMoteur1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.AquaGaugeMoteur1.DecimalPlaces = 0
        Me.AquaGaugeMoteur1.DialAlpha = 255
        Me.AquaGaugeMoteur1.DialBorderColor = System.Drawing.Color.Gray
        Me.AquaGaugeMoteur1.DialColor = System.Drawing.Color.Black
        Me.AquaGaugeMoteur1.DialText = Nothing
        Me.AquaGaugeMoteur1.DialTextColor = System.Drawing.Color.Gold
        Me.AquaGaugeMoteur1.DialTextFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AquaGaugeMoteur1.DialTextVOffset = 0
        Me.AquaGaugeMoteur1.DigitalValue = 0.0!
        Me.AquaGaugeMoteur1.DigitalValueBackAlpha = 1
        Me.AquaGaugeMoteur1.DigitalValueBackColor = System.Drawing.Color.White
        Me.AquaGaugeMoteur1.DigitalValueColor = System.Drawing.Color.Orange
        Me.AquaGaugeMoteur1.DigitalValueDecimalPlaces = 0
        Me.AquaGaugeMoteur1.Glossiness = 40.0!
        Me.AquaGaugeMoteur1.Location = New System.Drawing.Point(6, 37)
        Me.AquaGaugeMoteur1.MaxValue = 20000.0!
        Me.AquaGaugeMoteur1.MinValue = 0.0!
        Me.AquaGaugeMoteur1.Name = "AquaGaugeMoteur1"
        Me.AquaGaugeMoteur1.NoOfSubDivisions = 1
        Me.AquaGaugeMoteur1.PointerColor = System.Drawing.Color.Black
        Me.AquaGaugeMoteur1.RimAlpha = 255
        Me.AquaGaugeMoteur1.RimColor = System.Drawing.Color.Gold
        Me.AquaGaugeMoteur1.ScaleColor = System.Drawing.Color.Gold
        Me.AquaGaugeMoteur1.ScaleFontSizeDivider = 25
        Me.AquaGaugeMoteur1.Size = New System.Drawing.Size(195, 195)
        Me.AquaGaugeMoteur1.TabIndex = 117
        Me.AquaGaugeMoteur1.Threshold1Color = System.Drawing.Color.LawnGreen
        Me.AquaGaugeMoteur1.Threshold1Start = 0.0!
        Me.AquaGaugeMoteur1.Threshold1Stop = 2000.0!
        Me.AquaGaugeMoteur1.Threshold2Color = System.Drawing.Color.Red
        Me.AquaGaugeMoteur1.Threshold2Start = 16000.0!
        Me.AquaGaugeMoteur1.Threshold2Stop = 20000.0!
        Me.AquaGaugeMoteur1.Value = 0.0!
        Me.AquaGaugeMoteur1.ValueToDigital = True
        '
        'LabelVitesse1
        '
        Me.LabelVitesse1.AutoSize = True
        Me.LabelVitesse1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelVitesse1.ForeColor = System.Drawing.Color.Red
        Me.LabelVitesse1.Location = New System.Drawing.Point(27, 234)
        Me.LabelVitesse1.Name = "LabelVitesse1"
        Me.LabelVitesse1.Size = New System.Drawing.Size(63, 13)
        Me.LabelVitesse1.TabIndex = 113
        Me.LabelVitesse1.Text = "Vitesse 1:"
        '
        'LabelVitesse2
        '
        Me.LabelVitesse2.AutoSize = True
        Me.LabelVitesse2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelVitesse2.ForeColor = System.Drawing.Color.Blue
        Me.LabelVitesse2.Location = New System.Drawing.Point(239, 234)
        Me.LabelVitesse2.Name = "LabelVitesse2"
        Me.LabelVitesse2.Size = New System.Drawing.Size(63, 13)
        Me.LabelVitesse2.TabIndex = 114
        Me.LabelVitesse2.Text = "Vitesse 2:"
        '
        'CheckBoxSimuSynchroSpeeds
        '
        Me.CheckBoxSimuSynchroSpeeds.AutoSize = True
        Me.CheckBoxSimuSynchroSpeeds.Location = New System.Drawing.Point(1101, 327)
        Me.CheckBoxSimuSynchroSpeeds.Name = "CheckBoxSimuSynchroSpeeds"
        Me.CheckBoxSimuSynchroSpeeds.Size = New System.Drawing.Size(46, 17)
        Me.CheckBoxSimuSynchroSpeeds.TabIndex = 126
        Me.CheckBoxSimuSynchroSpeeds.Text = "Non"
        Me.CheckBoxSimuSynchroSpeeds.UseVisualStyleBackColor = True
        '
        'DataLogger
        '
        Me.DataLogger.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataLogger.Controls.Add(Me.zg1)
        Me.DataLogger.Location = New System.Drawing.Point(7, 360)
        Me.DataLogger.Name = "DataLogger"
        Me.DataLogger.Size = New System.Drawing.Size(1362, 390)
        Me.DataLogger.TabIndex = 119
        Me.DataLogger.TabStop = False
        Me.DataLogger.Text = "Data Log"
        '
        'zg1
        '
        Me.zg1.Location = New System.Drawing.Point(5, 19)
        Me.zg1.Name = "zg1"
        Me.zg1.ScrollGrace = 0.0R
        Me.zg1.ScrollMaxX = 0.0R
        Me.zg1.ScrollMaxY = 0.0R
        Me.zg1.ScrollMaxY2 = 0.0R
        Me.zg1.ScrollMinX = 0.0R
        Me.zg1.ScrollMinY = 0.0R
        Me.zg1.ScrollMinY2 = 0.0R
        Me.zg1.Size = New System.Drawing.Size(1351, 377)
        Me.zg1.TabIndex = 0
        '
        'TimerDataLogger
        '
        Me.TimerDataLogger.Interval = 1000
        '
        'SerialPort1
        '
        '
        'ProgressBarThrottleMotors
        '
        Me.ProgressBarThrottleMotors._Dessin = SynchTwinRcEngine_Interface.UcV_ProgressBar.Look.LookSmooth
        Me.ProgressBarThrottleMotors._Maxi = 100
        Me.ProgressBarThrottleMotors._Mini = 0
        Me.ProgressBarThrottleMotors._Value = 50
        Me.ProgressBarThrottleMotors.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ProgressBarThrottleMotors.Location = New System.Drawing.Point(208, 38)
        Me.ProgressBarThrottleMotors.Name = "ProgressBarThrottleMotors"
        Me.ProgressBarThrottleMotors.Size = New System.Drawing.Size(25, 193)
        Me.ProgressBarThrottleMotors.TabIndex = 126
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1373, 753)
        Me.Controls.Add(Me.DataLogger)
        Me.Controls.Add(Me.CheckBoxSimuSynchroSpeeds)
        Me.Controls.Add(Me.Moteurs)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.ButtonSettings)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.ButtonAbout)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "SynchTwinRcEngine Programer (module maître ou esclave)"
        CType(Me.TrackBarMotors, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBoxGlowPlugOnOff, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxGlowPlug, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarRudder, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxAuxMaxi, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxAuxMiddle, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxAuxMini, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PictureBoxConnectedOK, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.PictureBoxTimer2OnOff, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxTimer1OnOff, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Moteurs.ResumeLayout(False)
        Me.Moteurs.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.TrackBarSpeedSimu2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarSpeedSimu1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.DataLogger.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TrackBarMotors As System.Windows.Forms.TrackBar
    Friend WithEvents LabelMotors As System.Windows.Forms.Label
    Friend WithEvents ButtonExit As System.Windows.Forms.Button
    Friend WithEvents ComboPort As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ComboBaudRate As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ButtonSauvegardeCOM As System.Windows.Forms.Button
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents ButtonSettings As System.Windows.Forms.Button
    Friend WithEvents ButtonServoAuto As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents ButtonConfigDefaut As System.Windows.Forms.Button
    Friend WithEvents ButtonPlusNombrePales As System.Windows.Forms.Button
    Friend WithEvents ButtonPlusTelemetrie As System.Windows.Forms.Button
    Friend WithEvents ButtonMoinsTelemetrie As System.Windows.Forms.Button
    Friend WithEvents ButtonMoinsNombrePales As System.Windows.Forms.Button
    Friend WithEvents ButtonPlusModeAuxiliaire As System.Windows.Forms.Button
    Friend WithEvents ButtonMoinsModeAuxiliaire As System.Windows.Forms.Button
    Friend WithEvents ButtonPlusVitesseReponse As System.Windows.Forms.Button
    Friend WithEvents ButtonMoinsVitesseReponse As System.Windows.Forms.Button
    Friend WithEvents LabelModifications As System.Windows.Forms.Label
    Friend WithEvents ButtonAnnulerModif As System.Windows.Forms.Button
    Friend WithEvents CheckBoxInversionServo2 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBoxInversionServo1 As System.Windows.Forms.CheckBox
    Friend WithEvents TextVoltageExterne As System.Windows.Forms.TextBox
    Friend WithEvents TextTempInterne As System.Windows.Forms.TextBox
    Friend WithEvents TextVoltageInterne As System.Windows.Forms.TextBox
    Friend WithEvents textNombrePales As System.Windows.Forms.TextBox
    Friend WithEvents textAddresseI2C As System.Windows.Forms.TextBox
    Friend WithEvents textTelemetrieType As System.Windows.Forms.TextBox
    Friend WithEvents textAuxiliaireMode As System.Windows.Forms.TextBox
    Friend WithEvents textMaxiGenerale As System.Windows.Forms.TextBox
    Friend WithEvents textMiniGenerale As System.Windows.Forms.TextBox
    Friend WithEvents textDebutSynchro As System.Windows.Forms.TextBox
    Friend WithEvents textMaxiMoteurs As System.Windows.Forms.TextBox
    Friend WithEvents textTempsReponse As System.Windows.Forms.TextBox
    Friend WithEvents textIdleServo2 As System.Windows.Forms.TextBox
    Friend WithEvents textIdleServo1 As System.Windows.Forms.TextBox
    Friend WithEvents textCentreServo2 As System.Windows.Forms.TextBox
    Friend WithEvents textCentreServo1 As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents ButtonSauvegardeConfig As System.Windows.Forms.Button
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents ButtonReadCenter2 As System.Windows.Forms.Button
    Friend WithEvents ButtonReadCenter1 As System.Windows.Forms.Button
    Friend WithEvents ButtonIdleMoteur1 As System.Windows.Forms.Button
    Friend WithEvents ButtonIdleMoteur2 As System.Windows.Forms.Button
    Friend WithEvents ButtonMiniMaxGeneral As System.Windows.Forms.Button
    Friend WithEvents ButtonDebutSynchro As System.Windows.Forms.Button
    Friend WithEvents ButtonMaxiMoteurs As System.Windows.Forms.Button
    Friend WithEvents LabelInterType As System.Windows.Forms.Label
    Friend WithEvents ButtonReadSpeeds As System.Windows.Forms.Button
    Friend WithEvents PictureBoxTimer1OnOff As System.Windows.Forms.PictureBox
    Friend WithEvents ButtonAuxiliaireHelp As System.Windows.Forms.Button
    Friend WithEvents TextBoxAuxiliairePulse As System.Windows.Forms.TextBox
    Friend WithEvents ButtonReadAuxiliairePulse As System.Windows.Forms.Button
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents PictureBoxTimer2OnOff As System.Windows.Forms.PictureBox
    Friend WithEvents ButtonReadTempVoltage As System.Windows.Forms.Button
    Friend WithEvents ButtonMoteurs As System.Windows.Forms.Button
    Friend WithEvents Moteurs As System.Windows.Forms.GroupBox
    Friend WithEvents AquaGaugeMoteur1 As AquaControls.AquaGauge
    Friend WithEvents AquaGaugeMoteur2 As AquaControls.AquaGauge
    Friend WithEvents ButtonAbout As System.Windows.Forms.Button
    Friend WithEvents LabelVitesse1 As System.Windows.Forms.Label
    Friend WithEvents LabelVitesse2 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents DataLogger As System.Windows.Forms.GroupBox
    Friend WithEvents ButtonDataLogger As System.Windows.Forms.Button
    Friend WithEvents ButtonModuleType As System.Windows.Forms.Button
    Friend WithEvents CheckBoxFahrenheitDegrees As System.Windows.Forms.CheckBox
    Friend WithEvents Button_Connect As System.Windows.Forms.Button
    Friend WithEvents PictureBoxConnectedOK As System.Windows.Forms.PictureBox
    Friend WithEvents btnSend As System.Windows.Forms.Button
    Friend WithEvents txtMessage As System.Windows.Forms.TextBox
    Public WithEvents TimerSpeeds As System.Windows.Forms.Timer
    Public WithEvents TimerRXAuxiliaire As System.Windows.Forms.Timer
    Public WithEvents TimerHardwareInfos As System.Windows.Forms.Timer
    Public WithEvents TimerDataLogger As System.Windows.Forms.Timer
    Friend WithEvents TimerRXMotors As System.Windows.Forms.Timer
    Friend WithEvents SerialPort1 As System.IO.Ports.SerialPort
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents LabelAux As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ProgressBarThrottleMotors As SynchTwinRcEngine_Interface.UcV_ProgressBar
    Friend WithEvents ProgressBarThrottle As System.Windows.Forms.ProgressBar
    Friend WithEvents LabelAuxiRudder As System.Windows.Forms.Label
    Friend WithEvents ButtonAuxMaxi As System.Windows.Forms.Button
    Friend WithEvents ButtonAuxMiddle As System.Windows.Forms.Button
    Friend WithEvents ButtonAuxMini As System.Windows.Forms.Button
    Friend WithEvents PictureBoxAuxMaxi As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxAuxMiddle As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxAuxMini As System.Windows.Forms.PictureBox
    Friend WithEvents ProgressBarAuxiliary As System.Windows.Forms.ProgressBar
    Friend WithEvents TrackBarRudder As System.Windows.Forms.TrackBar
    Friend WithEvents zg1 As ZedGraph.ZedGraphControl
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBoxForceSpeedSimu1 As System.Windows.Forms.TextBox
    Friend WithEvents ButtonSpeedSimuOn As System.Windows.Forms.Button
    Friend WithEvents TextBoxDiffSpeedSimuConsigne As System.Windows.Forms.TextBox
    Friend WithEvents ButtonDiffSpeedSimuConsigne As System.Windows.Forms.Button
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents TrackBarSpeedSimu1 As System.Windows.Forms.TrackBar
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents TrackBarSpeedSimu2 As System.Windows.Forms.TrackBar
    Friend WithEvents TextBoxForceSpeedSimu2 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents LabelDEBUG As System.Windows.Forms.Label
    Friend WithEvents TextBoxDEBUG As System.Windows.Forms.TextBox
    Friend WithEvents PictureBoxGlowPlug As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxGlowPlugOnOff As System.Windows.Forms.PictureBox
    Friend WithEvents ButtonGlowPlugOnOff As System.Windows.Forms.Button
    Friend WithEvents CheckBoxSimuSynchroSpeeds As System.Windows.Forms.CheckBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents CheckBoxInversionAux As System.Windows.Forms.CheckBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents textGeneralMinMaxStopWatch As System.Windows.Forms.Label

End Class
