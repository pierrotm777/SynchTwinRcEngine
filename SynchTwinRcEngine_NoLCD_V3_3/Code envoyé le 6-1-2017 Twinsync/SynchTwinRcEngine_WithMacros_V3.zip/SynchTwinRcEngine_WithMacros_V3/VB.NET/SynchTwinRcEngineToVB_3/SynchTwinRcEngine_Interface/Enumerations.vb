﻿Public Enum ShowMsgImage
    Info
    Alert
    Confirm
    Critical
    Security
    UnderConstruction
End Enum

Public Enum ShowMsgButtons
    OkOnly
    ContinueCancel
    YesNo
    YesNoCancel
End Enum

Public Enum ShowMsgDefaultButton
    Button1
    Button2
    Button3
End Enum
