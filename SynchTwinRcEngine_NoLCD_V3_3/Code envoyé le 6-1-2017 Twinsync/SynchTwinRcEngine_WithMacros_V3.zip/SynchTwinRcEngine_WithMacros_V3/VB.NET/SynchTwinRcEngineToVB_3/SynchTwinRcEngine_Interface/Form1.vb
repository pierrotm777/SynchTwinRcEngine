﻿Imports System.IO
Imports System.IO.Ports
Imports System.Threading
Imports AquaControls.AquaGauge
Imports ZedGraph
Imports System.Globalization

Imports System.Text

Public Class Form1
    'Data Logger variables
    Dim myCurve As LineItem
    Dim myPane As GraphPane
    Dim list As New PointPairList
    Dim list2 As New PointPairList
    'Dim GraphIsEnable As Boolean
    Dim GraphIsReady As Boolean
    Dim GlowPlugIsOn As Boolean

#Region "Initialisation Port série"
    Private Sub Button_Connect_Click(sender As System.Object, e As System.EventArgs) Handles Button_Connect.Click
        Try

            SerialPort1.Open()
            Thread.Sleep(500)

            If SerialPort1.IsOpen Then
                PictureBoxConnectedOK.Image = My.Resources.rectangle_vert
                SerialPort1.Write(Trim(Str(0)) & vbCr) 'positionne les moteurs à la postion 0°
                Me.Text = ":-)"
                Button_Connect.Enabled = False
                ButtonAuxMiddle.PerformClick()
            Else
                PictureBoxConnectedOK.Image = My.Resources.rectangle_rouge
                Me.Text = ":-("

            End If

        Catch ex As Exception
            PictureBoxConnectedOK.Image = My.Resources.rectangle_rouge
            ShowMsg(ex.Message, ShowMsgImage.Info, "Erreur")

            'MsgBox("1) Le module n'est pas connecté !!!" & vbCrLf & "2) Choisissez le bon port série et sauvegardez !!!" & vbCrLf & "Connectez le module et redémarrez !!!", vbOK)
        End Try

    End Sub


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            TextBoxDEBUG.Enabled = True
            LabelDEBUG.Enabled = True

            AquaGaugeMoteur1.Value = 0
            AquaGaugeMoteur2.Value = 0
            AquaGaugeMoteur1.Glossiness = 80
            AquaGaugeMoteur2.Glossiness = 80
            AquaGaugeMoteur1.ValueToDigital = True
            AquaGaugeMoteur2.ValueToDigital = True
            AquaGaugeMoteur1.DialText = "tr/mn"
            AquaGaugeMoteur2.DialText = "tr/mn"
            AquaGaugeMoteur1.DigitalValue = 0
            AquaGaugeMoteur2.DigitalValue = 0
            AquaGaugeMoteur1.DigitalValueDecimalPlaces = 0
            AquaGaugeMoteur2.DigitalValueDecimalPlaces = 0
            AquaGaugeMoteur1.PointerColor = Color.Black
            AquaGaugeMoteur2.PointerColor = Color.Black
            AquaGaugeMoteur1.DigitalValueColor = Color.LightCyan
            AquaGaugeMoteur2.DigitalValueColor = Color.LightCyan

            LabelVitesse1.Text = "Vitesse 1: 0"
            LabelVitesse2.Text = "Vitesse 2: 0"

            LabelModifications.Enabled = False
            LabelModifications.Text = "..."


            Me.Location = New Point(100, 100)
            Me.Width = 400 'ou 989
            Me.Height = 400
            'Me.Top = ((Screen.PrimaryScreen.WorkingArea.Height / 2) - Me.Height)
            'Me.Left = ((Screen.PrimaryScreen.WorkingArea.Width / 2) - Me.Width)

            Dim BaudRates() As String = {"300", "1200", "2400", "4800", "9600", "14400", "19200", "28800", "38400", "57600", "115200"}
            ComboBaudRate.Items.AddRange(BaudRates)
            'ComboBaudRate.SelectedIndex = 4
            ComboBaudRate.SelectedIndex = My.Settings.SpeedIndex
            Try
                For Each sport As String In My.Computer.Ports.SerialPortNames
                    ComboPort.Items.Add(sport)
                Next

            Catch
                ShowMsg("Aucun port trouvé", ShowMsgImage.Info, "Erreur")
            End Try

            Try
                ComboPort.SelectedItem = My.Settings.COMPort

                SerialPort1.PortName = ComboPort.SelectedItem.ToString
                SerialPort1.BaudRate = ComboBaudRate.SelectedItem.ToString
                SerialPort1.DataBits = 8
                SerialPort1.Parity = Parity.None
                SerialPort1.StopBits = StopBits.One
                SerialPort1.Handshake = Handshake.None
                SerialPort1.Encoding = System.Text.Encoding.Default 'very important!

                ' Set the read/write timeouts
                SerialPort1.ReadTimeout = 500
                SerialPort1.WriteTimeout = 500
            Catch ex As Exception
                ComboPort.SelectedIndex = 0
                ShowMsg("Le module n'est pas connecté au port " & My.Settings.COMPort.ToString, ShowMsgImage.Info, "Erreur")
            End Try

            ButtonDataLogger.Enabled = False
            ReadSettings = ""

            PictureBox1.Image = My.Resources.Mosquito
            PictureBox2.Image = My.Resources.joystick
            PictureBoxTimer1OnOff.Image = My.Resources.rectangle_rouge
            PictureBoxTimer2OnOff.Image = My.Resources.rectangle_rouge
            PictureBoxConnectedOK.Image = My.Resources.rectangle_rouge

            PictureBoxAuxMini.Image = My.Resources.rectangle_rouge
            PictureBoxAuxMiddle.Image = My.Resources.rectangle_rouge
            PictureBoxAuxMaxi.Image = My.Resources.rectangle_rouge

            PictureBoxGlowPlugOnOff.Image = My.Resources.rectangle_rouge
            GlowPlugIsOn = False

            LabelAuxiRudder.Text = "Canal Auxiliaire Simulation"
            TrackBarRudder.Visible = False

            If textMiniGenerale.Text = "1500" And textMaxiGenerale.Text = "1500" Then
                EnableDisableButtonsRead(False)
            Else
                EnableDisableButtonsRead(True)
            End If

            ' Create the ToolTip and associate with the Form container.
            Dim toolTip1 As New ToolTip()
            ' Set up the delays for the ToolTip.
            toolTip1.AutoPopDelay = 5000
            toolTip1.InitialDelay = 1000
            toolTip1.ReshowDelay = 500
            toolTip1.IsBalloon = True
            ' Force the ToolTip text to be displayed whether or not the form is active.
            toolTip1.ShowAlways = True
            toolTip1.ForeColor = Color.Red

            toolTip1.SetToolTip(ButtonSettings, "Acces Configuration")
            toolTip1.SetToolTip(ButtonSauvegardeCOM, "Sauvegarde Port COM")
            toolTip1.SetToolTip(ButtonMiniMaxGeneral, "Lecture Min Max de votre radio!")
            toolTip1.SetToolTip(TrackBarMotors, "Simulation Manche moteurs")
            toolTip1.SetToolTip(TrackBarRudder, "Simulation Manche auxiliaire connecté  à la direction")
            toolTip1.SetToolTip(ButtonAuxMini, "Simulation Manche auxiliaire (position mini)")
            toolTip1.SetToolTip(ButtonAuxMiddle, "Simulation Manche auxiliaire (position milieu)")
            toolTip1.SetToolTip(ButtonAuxMaxi, "Simulation Manche auxiliaire (position maxi)")
            toolTip1.SetToolTip(ButtonServoAuto, "Test mouvement servos")
            toolTip1.SetToolTip(ButtonReadTempVoltage, "Lecture Température,Voltage Externe et Interne")
            toolTip1.SetToolTip(ButtonMoteurs, "Lecture Vitesse, Simulation Vitesse, Graphique")
            toolTip1.SetToolTip(ButtonDataLogger, "Graphique Rotation moteurs en tr/mn")

        Catch ex As Exception
            ShowMsg(ex.Message, ShowMsgImage.Info, "Erreur")
        End Try
    End Sub

    Private Sub ButtonExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonExit.Click
        SerialPort1.Close()
        Me.Close()
    End Sub

    Private Sub ShowMsgForm_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        'Dim messageBoxVB As New System.Text.StringBuilder()
        'messageBoxVB.AppendFormat("{0} = {1}", "CloseReason", e.CloseReason)
        'messageBoxVB.AppendLine()
        'messageBoxVB.AppendFormat("{0} = {1}", "Cancel", e.Cancel)
        'messageBoxVB.AppendLine()
        'MessageBox.Show(messageBoxVB.ToString(), "FormClosing Event")
        TimerDataLogger.Enabled = False
        TimerHardwareInfos.Enabled = False
        TimerRXAuxiliaire.Enabled = False
        TimerRXMotors.Enabled = False

    End Sub


    Private Sub ButtonSauvegardeCOM_Click(sender As System.Object, e As System.EventArgs) Handles ButtonSauvegardeCOM.Click
        My.Settings.COMPort = ComboPort.SelectedItem.ToString
        My.Settings.SpeedIndex = Convert.ToByte(ComboBaudRate.SelectedIndex)
        My.Settings.Save()
    End Sub
#End Region

#Region "Handles"

    Private Sub TrackBarMotors_MouseUp(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TrackBarMotors.MouseUp
        Try
            SerialPort1.Write(Trim(Str(pos)) & vbCr)
        Catch ex As Exception
            ShowMsg("Please,connect to the module!", ShowMsgImage.Info, "Erreur")
        End Try

    End Sub
    Private Sub TrackBarMotors_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TrackBarMotors.ValueChanged
        pos = CInt(TrackBarMotors.Value)
        LabelMotors.Text = pos
        ProgressBarThrottle.Value = pos
    End Sub

    'Utilisé en mode Auxiliaire 4
    Private Sub TrackBarRudder_MouseUp(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TrackBarRudder.MouseUp
        Try
            SerialPort1.Write(Trim(Str(posRudder + 180)) & vbCr) '180 to 360
        Catch ex As Exception
            ShowMsg("Please,connect to the module!", ShowMsgImage.Info, "Erreur")
        End Try
    End Sub
    Private Sub TrackBarRudder_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TrackBarRudder.ValueChanged
        Try
            posRudder = CInt(TrackBarRudder.Value)
            LabelAux.Text = posRudder
            ProgressBarAuxiliary.Value = posRudder
        Catch ex As Exception
            ShowMsg(ex.Message, ShowMsgImage.Info, "Erreur")
        End Try
    End Sub

    'Utilisé en simulation (force la vitesse des moteurs)
    Private Sub TrackBarSpeedSimu1_MouseUp(sender As System.Object, e As System.EventArgs) Handles TrackBarSpeedSimu1.MouseUp
        Try
            If CheckBoxSimuSynchroSpeeds.Checked = True Then TrackBarSpeedSimu2.Value = TrackBarSpeedSimu1.Value
            SerialPort1.Write(Trim(MessageToSend) & vbCr)
            MessageToSend = ""
        Catch ex As Exception
            ShowMsg("Please,connect to the module!", ShowMsgImage.Info, "Erreur")
        End Try
    End Sub
    Private Sub TrackBarSpeedSimu1_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TrackBarSpeedSimu1.ValueChanged
        Try
            TextBoxForceSpeedSimu1.Text = Str(TrackBarSpeedSimu1.Value)

            MessageToSend = ""
            MessageToSend = "99999" & ","
            MessageToSend &= TextBoxForceSpeedSimu1.Text & ","
            MessageToSend &= TextBoxForceSpeedSimu2.Text & ","
            MessageToSend &= TextBoxDiffSpeedSimuConsigne.Text

            'MsgBox(MessageToSend)
            SerialPort1.Write(Trim(MessageToSend) & vbCr)
            MessageToSend = ""
        Catch ex As Exception
            ShowMsg(ex.Message, ShowMsgImage.Info, "Erreur")
        End Try
    End Sub
    Private Sub TrackBarSpeedSimu2_MouseUp(sender As System.Object, e As System.EventArgs) Handles TrackBarSpeedSimu2.MouseUp
        Try
            If CheckBoxSimuSynchroSpeeds.Checked = True Then TrackBarSpeedSimu1.Value = TrackBarSpeedSimu2.Value
            SerialPort1.Write(Trim(MessageToSend) & vbCr)
            MessageToSend = ""
        Catch ex As Exception
            ShowMsg("Please,connect to the module!", ShowMsgImage.Info, "Erreur")
        End Try
    End Sub
    Private Sub TrackBarSpeedSimu2_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TrackBarSpeedSimu2.ValueChanged
        Try
            TextBoxForceSpeedSimu2.Text = Str(TrackBarSpeedSimu2.Value)

            MessageToSend = ""
            MessageToSend = "99999" & ","
            MessageToSend &= TextBoxForceSpeedSimu1.Text & ","
            MessageToSend &= TextBoxForceSpeedSimu2.Text & ","
            MessageToSend &= TextBoxDiffSpeedSimuConsigne.Text

            'MsgBox(MessageToSend)
            SerialPort1.Write(Trim(MessageToSend) & vbCr)
        Catch ex As Exception
            ShowMsg(ex.Message, ShowMsgImage.Info, "Erreur")
        End Try
    End Sub

    Private Sub CheckBoxSimuSynchroSpeeds_Click(sender As System.Object, e As System.EventArgs) Handles CheckBoxSimuSynchroSpeeds.CheckStateChanged
        LabelModifications.Enabled = True
        LabelModifications.ForeColor = Color.Red
        LabelModifications.Text = "Modifications non sauvegardées !"
        If (CheckBoxSimuSynchroSpeeds.Checked = True) Then
            CheckBoxSimuSynchroSpeeds.Text = "Oui"
            TrackBarSpeedSimu2.Value = TrackBarSpeedSimu1.Value
        Else
            CheckBoxSimuSynchroSpeeds.Text = "Non"
        End If

    End Sub



    Private Sub ButtonSpeedSimuOn_Click(sender As System.Object, e As System.EventArgs) Handles ButtonSpeedSimuOn.Click
        'format envoyé : 99999,1656,1653,100
        TrackBarSpeedSimu1.Value = CInt(TextBoxForceSpeedSimu1.Text)
        TrackBarSpeedSimu2.Value = CInt(TextBoxForceSpeedSimu2.Text)

        MessageToSend = ""
        MessageToSend = "99999" & ","
        MessageToSend &= TextBoxForceSpeedSimu1.Text & ","
        MessageToSend &= TextBoxForceSpeedSimu2.Text & ","
        MessageToSend &= TextBoxDiffSpeedSimuConsigne.Text

        'MsgBox(MessageToSend)
        SerialPort1.Write(Trim(MessageToSend) & vbCr)

        Thread.Sleep(1000) 'assure le temps nécessaire à la sauvegarde

    End Sub


    Private Sub textCentreServo1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textCentreServo1.TextChanged
        LabelModifications.Enabled = True
        LabelModifications.ForeColor = Color.Red
        LabelModifications.Text = "Modifications non sauvegardées !"
    End Sub
    Private Sub textCentreServo2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textCentreServo2.TextChanged
        LabelModifications.Enabled = True
        LabelModifications.ForeColor = Color.Red
        LabelModifications.Text = "Modifications non sauvegardées !"
    End Sub
    Private Sub textIdleServo1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textIdleServo1.TextChanged
        LabelModifications.Enabled = True
        LabelModifications.ForeColor = Color.Red
        LabelModifications.Text = "Modifications non sauvegardées !"
    End Sub
    Private Sub textIdleServo2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textIdleServo2.TextChanged
        LabelModifications.Enabled = True
        LabelModifications.ForeColor = Color.Red
        LabelModifications.Text = "Modifications non sauvegardées !"
    End Sub
    Private Sub textTempsReponse_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textTempsReponse.TextChanged
        LabelModifications.Enabled = True
        LabelModifications.ForeColor = Color.Red
        LabelModifications.Text = "Modifications non sauvegardées !"
    End Sub
    Private Sub textMaxiMoteurs_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textMaxiMoteurs.TextChanged
        LabelModifications.Enabled = True
        LabelModifications.ForeColor = Color.Red
        LabelModifications.Text = "Modifications non sauvegardées !"
    End Sub
    Private Sub textDebutSynchro_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textDebutSynchro.TextChanged
        LabelModifications.Enabled = True
        LabelModifications.ForeColor = Color.Red
        LabelModifications.Text = "Modifications non sauvegardées !"
    End Sub
    Private Sub textMiniGenerale_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textMiniGenerale.TextChanged
        LabelModifications.Enabled = True
        LabelModifications.ForeColor = Color.Red
        LabelModifications.Text = "Modifications non sauvegardées !"
    End Sub
    Private Sub textMaxiGenerale_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textMaxiGenerale.TextChanged
        LabelModifications.Enabled = True
        LabelModifications.ForeColor = Color.Red
        LabelModifications.Text = "Modifications non sauvegardées !"
    End Sub
    Private Sub textAuxiliaireMode_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textAuxiliaireMode.TextChanged
        LabelModifications.Enabled = True
        LabelModifications.ForeColor = Color.Red
        LabelModifications.Text = "Modifications non sauvegardées !"
    End Sub
    Private Sub textTelemetrieType_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textTelemetrieType.TextChanged
        LabelModifications.Enabled = True
        LabelModifications.ForeColor = Color.Red
        LabelModifications.Text = "Modifications non sauvegardées !"
    End Sub
    Private Sub textAddresseI2C_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textAddresseI2C.TextChanged
        LabelModifications.Enabled = True
        LabelModifications.ForeColor = Color.Red
        LabelModifications.Text = "Modifications non sauvegardées !"
    End Sub
    Private Sub textNombrePales_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textNombrePales.TextChanged
        LabelModifications.Enabled = True
        LabelModifications.ForeColor = Color.Red
        LabelModifications.Text = "Modifications non sauvegardées !"
    End Sub

    Private Sub CheckBoxInversionServo1_Click(sender As System.Object, e As System.EventArgs) Handles CheckBoxInversionServo1.CheckStateChanged
        LabelModifications.Enabled = True
        LabelModifications.ForeColor = Color.Red
        LabelModifications.Text = "Modifications non sauvegardées !"
        If (CheckBoxInversionServo1.Checked = True) Then CheckBoxInversionServo1.Text = "Oui" Else CheckBoxInversionServo1.Text = "Non"
    End Sub
    Private Sub CheckBoxInversionServo2_Click(sender As System.Object, e As System.EventArgs) Handles CheckBoxInversionServo2.CheckStateChanged
        LabelModifications.Enabled = True
        LabelModifications.ForeColor = Color.Red
        LabelModifications.Text = "Modifications non sauvegardées !"
        If (CheckBoxInversionServo2.Checked = True) Then CheckBoxInversionServo2.Text = "Oui" Else CheckBoxInversionServo2.Text = "Non"
    End Sub
    Private Sub CheckBoxFahrenheitDegrees_Click(sender As System.Object, e As System.EventArgs) Handles CheckBoxFahrenheitDegrees.CheckStateChanged
        LabelModifications.Enabled = True
        LabelModifications.ForeColor = Color.Red
        LabelModifications.Text = "Modifications non sauvegardées !"
        If CheckBoxFahrenheitDegrees.Checked = False Then CheckBoxFahrenheitDegrees.Text = "°C" Else CheckBoxFahrenheitDegrees.Text = "°F"
    End Sub
    Private Sub CheckBoxInversionAux_Click(sender As System.Object, e As System.EventArgs) Handles CheckBoxInversionAux.CheckStateChanged
        LabelModifications.Enabled = True
        LabelModifications.ForeColor = Color.Red
        LabelModifications.Text = "Modifications non sauvegardées !"
        If (CheckBoxInversionAux.Checked = True) Then CheckBoxInversionAux.Text = "Oui" Else CheckBoxInversionAux.Text = "Non"
    End Sub

#End Region

#Region "Buttons Min Max"

    Private Sub ButtonMoinsVitesseReponse_Click(sender As System.Object, e As System.EventArgs) Handles ButtonMoinsVitesseReponse.Click
        If Convert.ToInt16(textTempsReponse.Text) > 0 Then textTempsReponse.Text = Convert.ToString(Convert.ToInt16(textTempsReponse.Text) - 1)
    End Sub
    Private Sub ButtonPlusVitesseReponse_Click(sender As System.Object, e As System.EventArgs) Handles ButtonPlusVitesseReponse.Click
        If Convert.ToInt16(textTempsReponse.Text) < 4 Then textTempsReponse.Text = Convert.ToString(Convert.ToInt16(textTempsReponse.Text) + 1)
    End Sub

    Private Sub ButtonMoinsModeAuxiliaire_Click(sender As System.Object, e As System.EventArgs) Handles ButtonMoinsModeAuxiliaire.Click
        If Convert.ToInt16(textAuxiliaireMode.Text) > 1 Then textAuxiliaireMode.Text = Convert.ToString(Convert.ToInt16(textAuxiliaireMode.Text) - 1)
        LabelInterType.Text = ModeAuxiliaireTypeText(Convert.ToInt16(textAuxiliaireMode.Text))
    End Sub
    Private Sub ButtonPlusModeAuxiliaire_Click(sender As System.Object, e As System.EventArgs) Handles ButtonPlusModeAuxiliaire.Click
        If Convert.ToInt16(textAuxiliaireMode.Text) < 6 Then textAuxiliaireMode.Text = Convert.ToString(Convert.ToInt16(textAuxiliaireMode.Text) + 1)
        LabelInterType.Text = ModeAuxiliaireTypeText(Convert.ToInt16(textAuxiliaireMode.Text))
    End Sub

    Private Sub ButtonMoinsTelemetrie_Click(sender As System.Object, e As System.EventArgs) Handles ButtonMoinsTelemetrie.Click
        If Convert.ToInt16(textTelemetrieType.Text) > 0 Then textTelemetrieType.Text = Convert.ToString(Convert.ToInt16(textTelemetrieType.Text) - 1)
    End Sub
    Private Sub ButtonPlusTelemetrie_Click(sender As System.Object, e As System.EventArgs) Handles ButtonPlusTelemetrie.Click
        If Convert.ToInt16(textTelemetrieType.Text) < 6 Then textTelemetrieType.Text = Convert.ToString(Convert.ToInt16(textTelemetrieType.Text) + 1)
    End Sub

    Private Sub ButtonMoinsNombrePales_Click(sender As System.Object, e As System.EventArgs) Handles ButtonMoinsNombrePales.Click
        If Convert.ToInt16(textNombrePales.Text) > 1 Then textNombrePales.Text = Convert.ToString(Convert.ToInt16(textNombrePales.Text) - 1)
    End Sub
    Private Sub ButtonPlusNombrePales_Click(sender As System.Object, e As System.EventArgs) Handles ButtonPlusNombrePales.Click
        If Convert.ToInt16(textNombrePales.Text) < 5 Then textNombrePales.Text = Convert.ToString(Convert.ToInt16(textNombrePales.Text) + 1)
    End Sub

#End Region

#Region "Update Settings"
    Private Sub ButtonAnnulerModif_Click(sender As System.Object, e As System.EventArgs) Handles ButtonAnnulerModif.Click
        ButtonSettings.Select()
    End Sub
    Private Sub ButtonConfigDefaut_Click(sender As System.Object, e As System.EventArgs) Handles ButtonConfigDefaut.Click
        SerialPort1.Write(Trim(Str(364)) & vbCr)

        Thread.Sleep(5000) 'assure le temps nécessaire à la sauvegarde
        LabelModifications.Enabled = True
        LabelModifications.Text = "Modifications sauvegardées !"
        LabelModifications.ForeColor = Color.Green
    End Sub
    Private Sub ButtonSauvegardeConfig_Click(sender As System.Object, e As System.EventArgs) Handles ButtonSauvegardeConfig.Click
        'format envoyé : 1656,1653,1385,1385,2,2073,1389,1225,2073,1,0,0,1,3,20,0,0
        MessageToSend = ""
        MessageToSend = textCentreServo1.Text & ","     'centerposServo1
        MessageToSend &= textCentreServo2.Text & ","    'centerposServo2
        MessageToSend &= textIdleServo1.Text & ","      'idelposServos1
        MessageToSend &= textIdleServo2.Text & ","      'idelposServos2
        MessageToSend &= textTempsReponse.Text & ","    'responseTime
        MessageToSend &= textMaxiMoteurs.Text & ","     'fullThrottle
        MessageToSend &= textDebutSynchro.Text & ","    'beginSynchro
        MessageToSend &= textMiniGenerale.Text & ","    'minimumPulse_US
        MessageToSend &= textMaxiGenerale.Text & ","    'maximumPulse_US
        MessageToSend &= textAuxiliaireMode.Text & ","  'auxChannel
        If CheckBoxInversionServo1.Checked = True Then MessageToSend &= "1," Else MessageToSend &= "0," 'reverseServo1
        If CheckBoxInversionServo2.Checked = True Then MessageToSend &= "1," Else MessageToSend &= "0," 'reverseServo2
        MessageToSend &= textTelemetrieType.Text & ","  'telemetry
        MessageToSend &= textNombrePales.Text & ","     'nbPales
        MessageToSend &= textAddresseI2C.Text & ","     'I2C LCD
        MessageToSend &= "0," 'array(19).ToString & "," 'type de module (0=maître, 1=esclave)
        If CheckBoxFahrenheitDegrees.Checked = True Then MessageToSend &= "1" Else MessageToSend &= "0" 'Celcius/Fahrenheit
        'If CheckBoxInversionAux.Checked = True Then MessageToSend &= ",1" Else MessageToSend &= ",0" 'reverse Auxliary Chanel

        'MsgBox(MessageToSend)
        'SerialPort1.Write("5000,1200,1385,1385,2,2073,1389,1225,2073,1,0,0,1,3,20,0,0" & vbCr)
        SerialPort1.Write(Trim(MessageToSend) & vbCr)

        Thread.Sleep(3000) 'assure le temps nécessaire à la sauvegarde
        LabelModifications.Enabled = True
        LabelModifications.Text = "Modifications sauvegardées !"
        LabelModifications.ForeColor = Color.Green
    End Sub

#End Region

#Region "Réception Message venant de l'Arduino"
    Private Sub SerialPort1_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles SerialPort1.DataReceived
        'This sub gets called automatically when the com port recieves some data

        'Pause while all data is read
        Threading.Thread.Sleep(300)
        'Move recieved data into the buffer
        Dim SerialMessagRecieved As String = SerialPort1.ReadExisting.Replace(vbCrLf, "")


        'MsgBox(SerialMessagRecieved)
        'lecture config du module arduino 
        If Strings.Left(SerialMessagRecieved, 3) = "LLA" Then
            Try
                array = SerialMessagRecieved.Replace("LLA", "").Split("|")
                textCentreServo1.Text = array(0)
                textCentreServo2.Text = array(1)
                textIdleServo1.Text = array(2)
                textIdleServo2.Text = array(3)
                textTempsReponse.Text = array(4)
                textMaxiMoteurs.Text = array(5)
                textDebutSynchro.Text = array(6)
                textMiniGenerale.Text = array(7)
                textMaxiGenerale.Text = array(8)
                textAuxiliaireMode.Text = array(9)
                If array(10) = "1" Then CheckBoxInversionServo1.Checked = True Else CheckBoxInversionServo1.Checked = False
                If array(11) = "1" Then CheckBoxInversionServo2.Checked = True Else CheckBoxInversionServo2.Checked = False
                textTelemetrieType.Text = array(12)
                textAddresseI2C.Text = array(13)
                textNombrePales.Text = array(14)

                array(15) = "0" 'array(15) 'forcé à 0 avec version LCD
                TextVoltageInterne.Text = array(16) & "v"
                TextTempInterne.Text = array(17) & IIf(array(20) = "0", "°C", "°K")
                TextVoltageExterne.Text = array(18) & "v"
                ButtonModuleType.Text = IIf(array(19) = "0", "Maître", "Esclave")
                Me.Text = "SynchTwinRcEngine Programer (module " & IIf(array(19) = "0", "Maître)", "Esclave)") 'type de module ajouté au titre

                If array(20) = "0" Then CheckBoxFahrenheitDegrees.Checked = False Else CheckBoxFahrenheitDegrees.Checked = True
                CheckBoxFahrenheitDegrees.Text = IIf(array(20) = "0", "°C", "°K")

                LabelModifications.Enabled = False
                LabelModifications.Text = "..."

                LabelInterType.Text = ModeAuxiliaireTypeText(Convert.ToInt16(textAuxiliaireMode.Text))

            Catch ex As Exception
                ShowMsg(SerialMessagRecieved & vbCrLf & ex.Message, ShowMsgImage.Critical, "Erreur")
            End Try


        End If

        'lecture position canal moteur
        If Strings.Left(SerialMessagRecieved, 1) = "M" Then
            Select Case ModeType
                Case 1 : textCentreServo1.Text = SerialMessagRecieved.Replace("M", "")
                Case 2 : textCentreServo2.Text = SerialMessagRecieved.Replace("M", "")
                Case 31 : textIdleServo1.Text = SerialMessagRecieved.Replace("M", "")
                Case 32 : textIdleServo2.Text = SerialMessagRecieved.Replace("M", "")
                Case 4 : textTempsReponse.Text = SerialMessagRecieved.Replace("M", "")
                Case 51 : textMaxiMoteurs.Text = SerialMessagRecieved.Replace("M", "")
                Case 52 : textDebutSynchro.Text = SerialMessagRecieved.Replace("M", "")
                Case 53
                    pulseValue = CInt(SerialMessagRecieved.Replace("M", ""))
                    textGeneralMinMaxStopWatch.Text = CStr(30 - watch.Elapsed.Seconds)
                    textGeneralMinMaxStopWatch.ForeColor = Color.Red

                    pulseMinValue = CInt(textMiniGenerale.Text)
                    pulseMaxValue = CInt(textMaxiGenerale.Text)

                    If watch.IsRunning And watch.Elapsed.TotalSeconds < 30 Then
                        If pulseValue < pulseMinValue Then
                            pulseMinValue = pulseValue
                            textMiniGenerale.Text = Trim(CStr(pulseMinValue))
                        End If
                        If pulseValue > pulseMaxValue Then
                            pulseMaxValue = pulseValue
                            textMaxiGenerale.Text = Trim(CStr(pulseMaxValue))
                        End If
                    Else
                        watch.Stop()
                        TimerRXMotors.Enabled = False
                        textGeneralMinMaxStopWatch.ForeColor = Color.Green
                        textGeneralMinMaxStopWatch.Text = "Min Max OK"
                        EnableDisableButtonsRead(True)
                    End If
            End Select

            Dim NewPulse As Integer
            'convertion de Pulse (600,2400) en (valeur bar graph (0,100)
            NewPulse = mapValue(CInt(SerialMessagRecieved.Replace("M", "")),
                                        CInt(textIdleServo1.Text), CInt(textMaxiMoteurs.Text),
                                        Me.ProgressBarThrottleMotors._Mini, Me.ProgressBarThrottleMotors._Maxi)
            'MsgBox(NewPulse)
            Me.ProgressBarThrottleMotors._Value = NewPulse

            If NewPulse > Me.ProgressBarThrottleMotors._Maxi Then
                Me.ProgressBarThrottleMotors._Value = Me.ProgressBarThrottleMotors._Maxi
            End If
            If NewPulse < Me.ProgressBarThrottleMotors._Mini Then
                Me.ProgressBarThrottleMotors._Value = Me.ProgressBarThrottleMotors._Mini
            End If

        End If

        'lecture des capteurs de vitesse 1 et 2
        If Strings.Left(SerialMessagRecieved, 1) = "V" Then
            Try
                SpeedArray = SerialMessagRecieved.Replace("V", "").Split("|")

                LabelVitesse1.Text = "Vitesse 1: " & SpeedArray(0)
                LabelVitesse2.Text = "Vitesse 2: " & SpeedArray(1)
                AquaGaugeMoteur1.Value = CInt(SpeedArray(0))
                AquaGaugeMoteur2.Value = CInt(SpeedArray(1))
                AquaGaugeMoteur1.ValueToDigital = CInt(SpeedArray(0))
                AquaGaugeMoteur2.ValueToDigital = CInt(SpeedArray(1))

                'If GrahIsEnable = True Then 'lecture DataLogger
                ' Make up some data points based on the Sine function
                Dim i As Integer, x As Double ', y As Double, y2 As Double
                'For i = 0 To 35
                '    x = i * 5.0
                '    y = Math.Sin(i * Math.PI / 15.0) * 16.0
                '    y2 = y * 13.5
                '    list.Add(x, y)
                '    list2.Add(x, y2)
                'Next i
                If i < 10000 Then
                    x = New XDate(DateTime.Now) '(i + 11)
                    list.Add(x, Convert.ToDouble(SpeedArray(0)))
                    list2.Add(x, Convert.ToDouble(SpeedArray(1)))
                    i = i + 1

                End If
                GraphIsReady = True
                ButtonDataLogger.Enabled = True
            Catch ex As Exception
                ShowMsg(SerialMessagRecieved & vbCrLf & ex.Message, ShowMsgImage.Critical, "Erreur")
            End Try
        End If

        'lecture position canal auxiliaire
        If Strings.Left(SerialMessagRecieved, 1) = "A" Then
            TextBoxAuxiliairePulse.Text = SerialMessagRecieved.Replace("A", "")
        End If

        'lecture voltage arduino, temp arduino et voltage batterie RX
        If Strings.Left(SerialMessagRecieved, 3) = "STS" Then
            HardwareArray = SerialMessagRecieved.Replace("STS", "").Split("|")
            TextVoltageInterne.Text = HardwareArray(0) & "v"
            TextTempInterne.Text = HardwareArray(1) & IIf(CheckBoxFahrenheitDegrees.Checked, "°F", "°C")
            TextVoltageExterne.Text = HardwareArray(2) & "v"
        End If

        'lecture debug
        If Strings.Left(SerialMessagRecieved, 1) = "D" Then
            TextBoxDEBUG.Text = SerialMessagRecieved.Replace("D", "")
        End If


        'End If

    End Sub

    Private Function mapValue(x As Long, in_min As Long, in_max As Long, out_min As Long, out_max As Long) As Long
        Return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min
    End Function


#End Region



#Region "Read Buttons"
    Private Sub EnableDisableButtonsRead(state As Boolean)
        ButtonReadCenter1.Enabled = state
        ButtonReadCenter2.Enabled = state
        ButtonIdleMoteur1.Enabled = state
        ButtonIdleMoteur2.Enabled = state
        ButtonMaxiMoteurs.Enabled = state
        ButtonDebutSynchro.Enabled = state
        ButtonMoinsVitesseReponse.Enabled = state
        ButtonPlusVitesseReponse.Enabled = state

    End Sub

    Private Sub ButtonReadCenter1_Click(sender As System.Object, e As System.EventArgs) Handles ButtonReadCenter1.Click
        ModeType = 1
        If TimerRXAuxiliaire.Enabled = True Then
            TimerRXAuxiliaire.Enabled = False
            PictureBoxTimer2OnOff.Image = My.Resources.rectangle_rouge
        End If
        If TimerSpeeds.Enabled = True Then
            TimerSpeeds.Enabled = False
            PictureBoxTimer1OnOff.Image = My.Resources.rectangle_rouge
        End If

        If TimerRXMotors.Enabled = True Then
            TimerRXMotors.Enabled = False

        Else
            TimerRXMotors.Enabled = True
        End If
    End Sub
    Private Sub ButtonReadCenter2_Click(sender As System.Object, e As System.EventArgs) Handles ButtonReadCenter2.Click
        ModeType = 2
        If TimerRXAuxiliaire.Enabled = True Then
            TimerRXAuxiliaire.Enabled = False
            PictureBoxTimer2OnOff.Image = My.Resources.rectangle_rouge
        End If
        If TimerSpeeds.Enabled = True Then
            TimerSpeeds.Enabled = False
            PictureBoxTimer1OnOff.Image = My.Resources.rectangle_rouge
        End If

        If TimerRXMotors.Enabled = True Then
            TimerRXMotors.Enabled = False

        Else
            TimerRXMotors.Enabled = True
        End If
    End Sub


    Private Sub ButtonIdelMoteur1_Click(sender As System.Object, e As System.EventArgs) Handles ButtonIdleMoteur1.Click
        ModeType = 31
        If TimerRXAuxiliaire.Enabled = True Then
            TimerRXAuxiliaire.Enabled = False
            PictureBoxTimer2OnOff.Image = My.Resources.rectangle_rouge
        End If
        If TimerSpeeds.Enabled = True Then
            TimerSpeeds.Enabled = False
            PictureBoxTimer1OnOff.Image = My.Resources.rectangle_rouge
        End If

        If TimerRXMotors.Enabled = True Then
            TimerRXMotors.Enabled = False

        Else
            TimerRXMotors.Enabled = True
        End If
    End Sub
    Private Sub ButtonIdleMoteur2_Click(sender As System.Object, e As System.EventArgs) Handles ButtonIdleMoteur2.Click
        ModeType = 32
        If TimerRXAuxiliaire.Enabled = True Then
            TimerRXAuxiliaire.Enabled = False
            PictureBoxTimer2OnOff.Image = My.Resources.rectangle_rouge
        End If
        If TimerSpeeds.Enabled = True Then
            TimerSpeeds.Enabled = False
            PictureBoxTimer1OnOff.Image = My.Resources.rectangle_rouge
        End If

        If TimerRXMotors.Enabled = True Then
            TimerRXMotors.Enabled = False

        Else
            TimerRXMotors.Enabled = True
        End If
    End Sub

    Private Sub ButtonMaxiMoteurs_Click(sender As System.Object, e As System.EventArgs) Handles ButtonMaxiMoteurs.Click
        ModeType = 51
        If TimerRXAuxiliaire.Enabled = True Then
            TimerRXAuxiliaire.Enabled = False
            PictureBoxTimer2OnOff.Image = My.Resources.rectangle_rouge
        End If
        If TimerSpeeds.Enabled = True Then
            TimerSpeeds.Enabled = False
            PictureBoxTimer1OnOff.Image = My.Resources.rectangle_rouge
        End If

        If TimerRXMotors.Enabled = True Then
            TimerRXMotors.Enabled = False

        Else
            TimerRXMotors.Enabled = True
        End If
    End Sub
    Private Sub ButtonDebutSynchro_Click(sender As System.Object, e As System.EventArgs) Handles ButtonDebutSynchro.Click
        ModeType = 52
        If TimerRXAuxiliaire.Enabled = True Then
            TimerRXAuxiliaire.Enabled = False
            PictureBoxTimer2OnOff.Image = My.Resources.rectangle_rouge
        End If
        If TimerSpeeds.Enabled = True Then
            TimerSpeeds.Enabled = False
            PictureBoxTimer1OnOff.Image = My.Resources.rectangle_rouge
        End If

        If TimerRXMotors.Enabled = True Then
            TimerRXMotors.Enabled = False

        Else
            TimerRXMotors.Enabled = True
        End If
    End Sub

    Private Sub ButtonMiniMaxGeneral_Click(sender As System.Object, e As System.EventArgs) Handles ButtonMiniMaxGeneral.Click
        ModeType = 53
        If TimerRXAuxiliaire.Enabled = True Then
            TimerRXAuxiliaire.Enabled = False
            PictureBoxTimer2OnOff.Image = My.Resources.rectangle_rouge
        End If
        If TimerSpeeds.Enabled = True Then
            TimerSpeeds.Enabled = False
            PictureBoxTimer1OnOff.Image = My.Resources.rectangle_rouge
        End If

        If TimerRXMotors.Enabled = True Then
            TimerRXMotors.Enabled = False
            If watch.IsRunning = True Then watch.Stop()
            textGeneralMinMaxStopWatch.ForeColor = Color.Green
            textGeneralMinMaxStopWatch.Text = "Min Max OK"
            If textMiniGenerale.Text <> "1500" And textMaxiGenerale.Text <> "1500" Then
                EnableDisableButtonsRead(True)
            Else
                EnableDisableButtonsRead(False)
            End If

        Else
            TimerRXMotors.Enabled = True
            textMiniGenerale.Text = "1500"
            textMaxiGenerale.Text = "1500"
            ' Create new Stopwatch instance.
            watch = Stopwatch.StartNew()
        End If


    End Sub


    Private Sub ButtonReadSpeeds_Click(sender As System.Object, e As System.EventArgs) Handles ButtonReadSpeeds.Click
        If TimerRXAuxiliaire.Enabled = True Then
            TimerRXAuxiliaire.Enabled = False
            PictureBoxTimer2OnOff.Image = My.Resources.rectangle_vert
        End If
        If TimerRXMotors.Enabled = True Then
            TimerRXMotors.Enabled = False
        End If

        If TimerSpeeds.Enabled = True Then
            TimerSpeeds.Enabled = False
            PictureBoxTimer1OnOff.Image = My.Resources.rectangle_rouge
            AquaGaugeMoteur1.Value = 0
            AquaGaugeMoteur2.Value = 0
            AquaGaugeMoteur1.DigitalValue = 0
            AquaGaugeMoteur2.DigitalValue = 0
            LabelVitesse1.Text = "Vitesse 1: 0"
            LabelVitesse2.Text = "Vitesse 2: 0"
            'Me.ProgressBarThrottleMotors._Value = Me.ProgressBarThrottleMotors._Mini
        Else
            TimerSpeeds.Enabled = True
            PictureBoxTimer1OnOff.Image = My.Resources.rectangle_vert
        End If

    End Sub

    Private Sub ButtonReadAuxiliairePulse_Click(sender As System.Object, e As System.EventArgs) Handles ButtonReadAuxiliairePulse.Click
        If TimerSpeeds.Enabled = True Then
            TimerSpeeds.Enabled = False
            PictureBoxTimer1OnOff.Image = My.Resources.rectangle_rouge
        End If
        If TimerRXMotors.Enabled = True Then
            TimerRXMotors.Enabled = False
        End If

        If TimerRXAuxiliaire.Enabled = True Then
            TimerRXAuxiliaire.Enabled = False
            PictureBoxTimer2OnOff.Image = My.Resources.rectangle_rouge
        Else
            TimerRXAuxiliaire.Enabled = True
            PictureBoxTimer2OnOff.Image = My.Resources.rectangle_vert
        End If
    End Sub

    Private Sub ButtonReadTempVoltage_Click(sender As System.Object, e As System.EventArgs) Handles ButtonReadTempVoltage.Click
        'If SerialPort1.IsOpen Then
        '    TimerHardwareInfos.Enabled = False
        '    SerialPort1.Close()
        'Else
        '    SerialPort1.Open()
        '    TimerHardwareInfos.Enabled = True
        'End If
        TimerHardwareInfos.Enabled = Not TimerHardwareInfos.Enabled
    End Sub

    Private Sub ButtonMoteurs_Click(sender As System.Object, e As System.EventArgs) Handles ButtonMoteurs.Click
        If Me.Width = 945 Then
            Me.Width = 1389
        Else
            Me.Width = 945
            Me.Height = 400
        End If

    End Sub

#End Region

#Region "Timers"

    Private Sub TimerSpeeds_Tick(sender As System.Object, e As System.EventArgs) Handles TimerSpeeds.Tick
        SerialPort1.Write(Trim(Str(366)) & vbCr)
    End Sub

    Private Sub TimerAuxiliaire_Tick(sender As System.Object, e As System.EventArgs) Handles TimerRXAuxiliaire.Tick
        SerialPort1.Write(Trim(Str(367)) & vbCr)
    End Sub

    Private Sub TimerMotors_Tick(sender As System.Object, e As System.EventArgs) Handles TimerRXMotors.Tick
        SerialPort1.Write(Trim(Str(365)) & vbCr)
    End Sub

    Private Sub TimerHardware_Tick(sender As System.Object, e As System.EventArgs) Handles TimerHardwareInfos.Tick
        SerialPort1.Write(Trim(Str(368)) & vbCr)
    End Sub

#End Region

    Private Sub ButtonSettings_Click(sender As System.Object, e As System.EventArgs) Handles ButtonSettings.Click
        Me.Width = 945 ' ou 400
        Try
            SerialPort1.Write(Trim(Str(363)) & vbCr) 'recupération de la configuration du module

        Catch ex As Exception
            ShowMsg("Please,connect to the module!", ShowMsgImage.Info, "Erreur")
        End Try
    End Sub

    Private Sub ButtonServoAuto_Click(sender As System.Object, e As System.EventArgs) Handles ButtonServoAuto.Click
        Try
            SerialPort1.Write(Trim(Str(362)) & vbCr)
        Catch ex As Exception
            ShowMsg("Please,connect to the module!", ShowMsgImage.Info, "Erreur")
        End Try
    End Sub
    Private Sub ButtonAbout_Click_1(sender As System.Object, e As System.EventArgs) Handles ButtonAbout.Click
        ShowMsg("Copyright @2015" & vbCrLf & vbCrLf & "mailto:pierrotm777@gmail.com", ShowMsgImage.Info, "Erreur")
    End Sub

    Private Sub ButtonModuleType_Click(sender As System.Object, e As System.EventArgs) Handles ButtonModuleType.Click
        array(19) = IIf(array(19) = 0, 1, 0)
        Me.Text = "SynchTwinRcEngine Programer (module " & IIf(array(19) = 0, "Maître)", "Esclave)") 'type de module ajouté au titre
        ButtonModuleType.Text = IIf(array(19) = 0, "Maître", "Esclave")
        LabelModifications.Enabled = True
        LabelModifications.ForeColor = Color.Red
        LabelModifications.Text = "Modifications non sauvegardées !"
    End Sub

    Private Function ModeTypeText(mode As Integer) As String
        Dim StringMode As String = ""
        Select Case mode
            Case 0 : StringMode = "Synchronisation active"
            Case 1 : StringMode = "Centre Moteur 1"
            Case 2 : StringMode = "Centre Moteur 2"
            Case 3 : StringMode = "Position Sauvegarde moteurs 1 et 2"
            Case 4 : StringMode = "Vitesse réponse module , Interface PC"
            Case 5 : StringMode = "Max moteurs, début synchro et Mini Max général"
            Case 6 : StringMode = "Configuration Canal Auxiliaire, Nombre pales et télémetrie"
            Case 7 : StringMode = "Inversion Servo, RAZ EEProm"
            Case Else
                : StringMode = ""
        End Select
        Return StringMode
    End Function

    Private Function ModeAuxiliaireTypeText(mode As Integer) As String
        Dim StringMode As String = ""
        Select Case mode
            Case 1 : StringMode = "===> Auxiliaire non connecté"
                : ButtonAuxMini.Enabled = False : ButtonAuxMiddle.Enabled = False : ButtonAuxMaxi.Enabled = False
                : ButtonAuxMini.Visible = True : ButtonAuxMiddle.Visible = True : ButtonAuxMaxi.Visible = True
                : PictureBoxAuxMini.Visible = True : PictureBoxAuxMiddle.Visible = True : PictureBoxAuxMaxi.Visible = True
                : ProgressBarAuxiliary.Visible = False : LabelAux.Enabled = False : TrackBarRudder.Visible = False
                : PictureBoxAuxMini.Image = My.Resources.rectangle_gris : PictureBoxAuxMiddle.Image = My.Resources.rectangle_gris : PictureBoxAuxMaxi.Image = My.Resources.rectangle_gris

            Case 2 : StringMode = "===> Auxiliaire connecté à inter 3 positions"
                : ButtonAuxMini.Enabled = True : ButtonAuxMiddle.Enabled = True : ButtonAuxMaxi.Enabled = True
                : ButtonAuxMini.Visible = True : ButtonAuxMiddle.Visible = True : ButtonAuxMaxi.Visible = True
                : PictureBoxAuxMini.Visible = True : PictureBoxAuxMiddle.Visible = True : PictureBoxAuxMaxi.Visible = True
                : ProgressBarAuxiliary.Visible = True : LabelAux.Enabled = True : TrackBarRudder.Visible = False
                : PictureBoxAuxMini.Image = My.Resources.rectangle_rouge : PictureBoxAuxMiddle.Image = My.Resources.rectangle_vert : PictureBoxAuxMaxi.Image = My.Resources.rectangle_rouge

            Case 3, 5, 6 : StringMode = "===> Auxiliaire connecté à inter 2 positions"
                : ButtonAuxMini.Enabled = True : ButtonAuxMiddle.Enabled = False : ButtonAuxMaxi.Enabled = True
                : ButtonAuxMini.Visible = True : ButtonAuxMiddle.Visible = True : ButtonAuxMaxi.Visible = True
                : PictureBoxAuxMini.Visible = True : PictureBoxAuxMiddle.Visible = True : PictureBoxAuxMaxi.Visible = True
                : ProgressBarAuxiliary.Visible = True : LabelAux.Enabled = True : TrackBarRudder.Visible = False
                : PictureBoxAuxMini.Image = My.Resources.rectangle_vert : PictureBoxAuxMiddle.Image = My.Resources.rectangle_gris : PictureBoxAuxMaxi.Image = My.Resources.rectangle_rouge

            Case 4 : StringMode = "===> Auxiliaire connecté à la direction"
                : ButtonAuxMini.Enabled = False : ButtonAuxMiddle.Enabled = False : ButtonAuxMaxi.Enabled = False
                : ButtonAuxMini.Visible = False : ButtonAuxMiddle.Visible = False : ButtonAuxMaxi.Visible = False
                : PictureBoxAuxMini.Visible = False : PictureBoxAuxMiddle.Visible = False : PictureBoxAuxMaxi.Visible = False
                : LabelAuxiRudder.Text = "Canal Direction Simulation" : TrackBarRudder.Visible = True : TrackBarRudder.Value = 90
                : ProgressBarAuxiliary.Visible = True 'LabelAux.Text = 0 ': ProgressBarAuxiliary.Value = 90
        End Select
        Return StringMode
    End Function

    Private Sub ButtonAuxiliaireHelp_Click(sender As System.Object, e As System.EventArgs) Handles ButtonAuxiliaireHelp.Click
        Select Case Convert.ToInt16(textAuxiliaireMode.Text)
            Case 1 : ShowMsg("MODE1: Auxiliaire non utilisé" & vbCrLf & _
                            "C'est le mode dans lequel le module devra être is l'entrée AUX n'est pas conectée." & vbCrLf & _
                            "Le module laisse l'entrée gaz controler les servos jusqu'à 1/5eme de sa position." & vbCrLf & _
                            "Au dela des 1/5eme des gaz, le module contrôle la position des servos et synchronise les moteurs." & vbCrLf & _
                            "Si le manche des gaz bouge, le processus est repete.", ShowMsgImage.Info, "Canal Auxiliaire <--> Mode 1")
            Case 2 : ShowMsg("MODE2: Fonctionnement indépendent des moteurs" & vbCrLf & _
                            "Dans ce mode, l'entrée AUX est connectée à un switch 3 positions de l'émetteur." & vbCrLf & _
                            "Si la sortie de ce canal est en dessous de 1/3 de sa course, le moteur 1 est contrôllé par" & vbCrLf & _
                            "le manche des gaz pendant que le moteur 2 est maintenu dans la position 'idle' programée." & vbCrLf & _
                            "Si la sortie du canal AUX est entre 1/3 et 2/3 de sa course, le manche des gaz contrôle les" & vbCrLf & _
                            "deux moteurs et le module est comme dans le mode 1.Si la sortie AUX est au dela des 2/3" & vbCrLf & _
                            "de sa course, le manche des gaz contrôle le moteur 2 et le moteur 1 est maintenu dans la" & vbCrLf & _
                            "position 'idle' programmée.Ce mode est idéal pour l'ajustement du mélange de carburant.", ShowMsgImage.Info, "Canal Auxiliaire <--> Mode 2")
            Case 3 : ShowMsg("MODE3: Synchronisation On/Off" & vbCrLf & _
                            "Dans ce mode, le canal AUX est ossocié à un switch 2 positions de l'émetteur." & vbCrLf & _
                            "Dans une position,la synchronisation est active.Dans l'autre position, le module" & vbCrLf & _
                            "ne fait rien et se comporte comme un cable 'Y' (bien que les directions et centres" & vbCrLf & _
                            "servos soient toujours controles par le module). Il s'agit d'un mode utile pour" & vbCrLf & _
                            "comprendre comment votre avion va réagir alors que les moteurs sont contrôlés par le module.", ShowMsgImage.Info, "Canal Auxiliaire <--> Mode 3")
            Case 4 : ShowMsg("MODE4: AUX CH is for Rudder Steering(!!non utilisable pour l'instant!!)" & vbCrLf & _
                            "Dans ce mode, le module se comporte comme dans le mode1 (canal aux. non connecté) avant les 1/3 moteur." & vbCrLf & _
                            "Au delà des 1/3 moteur, le canal auxiliaire est supposé être relié à la sortie du récepteur de gouvernail" & vbCrLf & _
                            "Il y a une zone morte autour du centre (ainsi, le trim du gouvernail est sans effet sur les moteurs)." & vbCrLf & _
                            "Quand le manche du gouvernail dépasse cette zone morte, il augmente la vitesse d'un moteur." & vbCrLf & _
                            "Bouger le manche du gouvernail dans l'autre sens augmente la vitesse de l'autre moteur." & vbCrLf & _
                            "Le gouvernail en position maxi d'un côté, se traduira par environ la moitié des gaz sur le moteur pour ce même côté." & vbCrLf & _
                            "Cela permet, lors du roulage des avions, le contrôle aux moteurs plutôt que d'une roue orientable ." & vbCrLf & _
                            "Ce mode authorize aussi des manoeuvres accrobatiques impossibles avec un seul moteur." & vbCrLf & _
                            "Ce mode est déactivé si un des moteurs est à l'arrêt." & vbCrLf & _
                            "Il est actif si les deux moteurs ou aucun des moteurs fonctionnent." & vbCrLf & _
                            "Cela permet les essais au banc ainsi que l'exploitation si les deux moteurs sont en marche", ShowMsgImage.Info, "Canal Auxiliaire <--> Mode 4")
                '"Les moteurs ne sont pas synchronisés tant que le manche du gouvernail n'est pas au-dessus" & vbCrLf & _
                '"du point de gouvernail bouvillon de désengagement ( 1/3 de la puissance )", ShowMsgImage.Info)
            Case 5 : ShowMsg("Canal auxilaire contrôle les bougies (FACTORY PRESET MODE)" & vbCrLf & _
                            "Dans ce mode, la canal auxilaire active ou pas le contrôle des bougies." & vbCrLf & _
                            "Un inter 2 positions sera utilisé. Dans une position les bougies seront" & vbCrLf & _
                            "allimentées et pas dans l'autre.", ShowMsgImage.Info, "Canal Auxiliaire <--> Mode 5")
            Case 6 : ShowMsg("Canal auxilaire contrôle les bougies (sans zone morte)", ShowMsgImage.Info, "Canal Auxiliaire <--> Mode 6")
                'ShowMsg(ByVal Text As String, ByVal Question As String, ByVal Buttons As ShowMsgButtons, ByVal DefaultButton As ShowMsgDefaultButton, ByVal Title As String) 
        End Select
    End Sub


    Private Sub ButtonDataLogger_Click(sender As System.Object, e As System.EventArgs) Handles ButtonDataLogger.Click
        Me.Width = 1389 'ou 989

        If Me.Height = 400 Then
            Me.Height = 789
            zg1.GraphPane = New GraphPane()
        Else
            Me.Height = 400
            zg1.GraphPane = New GraphPane()
        End If

        'http://www.codeproject.com/Articles/5431/A-flexible-charting-library-for-NET
        'ou
        'http://zedgraph.dariowiz.com/index8da4.html?title=Line_%26_Symbol_Charts

        'voir http://www.cnblogs.com/luxiaoxun/p/4161782.html

        myPane = zg1.GraphPane
        ' Set the titles and axis labels
        myPane.Title.Text = "Vitesses Moteurs tr/mn"
        myPane.XAxis.Title.Text = "Date"
        myPane.YAxis.Title.Text = "Tours/Minutes Moteur 1"
        myPane.Y2Axis.Title.Text = "Tours/Minutes Moteur 2"


        ' Change the color of the title
        myPane.Title.FontSpec.FontColor = Color.Green
        myPane.XAxis.Title.FontSpec.FontColor = Color.Green
        myPane.YAxis.Title.FontSpec.FontColor = Color.Green

        'myPane.XAxis.Title.FontSpec.IsBold = True
        'myPane.XAxis.Title.FontSpec.Size = 18
        'myPane.YAxis.Title.FontSpec.Size = 18
        'myPane.Title.FontSpec.FontColor = Color.Red
        'myPane.Title.FontSpec.Size = 22
        'myPane.XAxis.Scale.IsUseTenPower = True
        'myPane.YAxis.Scale.IsUseTenPower = True


        myPane.XAxis.Type = AxisType.Date
        myPane.XAxis.Scale.Format = "HH:mm:ss.fff"
        myPane.XAxis.Scale.Min = New XDate(DateTime.Now)
        myPane.XAxis.Scale.Max = New XDate(DateTime.Now.AddSeconds(10))
        myPane.XAxis.Scale.MinorUnit = DateUnit.Second
        myPane.XAxis.Scale.MajorUnit = DateUnit.Second
        'myPane.XAxis.Scale.MajorUnit = DateUnit.Minute



        ' Make up some data points based on the Sine function
        'Dim i As Integer, x As Double, y As Double, y2 As Double
        'For i = 0 To 35
        '    x = i * 5.0
        '    y = Math.Sin(i * Math.PI / 15.0) * 16.0
        '    y2 = y * 13.5
        '    list.Add(x, y)
        '    list2.Add(x, y2)
        'Next i

        ' Generate a red curve with diamond symbols, and "Alpha" in the legend
        myCurve = myPane.AddCurve("Vitesse1", list, Color.Red, SymbolType.Diamond)
        ' Fill the symbols with white
        myCurve.Symbol.Fill = New Fill(Color.GreenYellow)
        ' Generate a blue curve with circle symbols, and "Beta" in the legend
        myCurve = myPane.AddCurve("Vitesse2", list2, Color.Blue, SymbolType.Circle)
        ' Fill the symbols with white
        myCurve.Symbol.Fill = New Fill(Color.LightPink)



        'Associate this curve with the Y2 axis (axe cental de y=0)
        'myCurve.IsY2Axis = True

        ' Show the x axis grid
        myPane.XAxis.MajorGrid.IsVisible = True

        ' Make the Y axis scale red
        myPane.YAxis.Scale.FontSpec.FontColor = Color.Red
        myPane.YAxis.Title.FontSpec.FontColor = Color.Red
        ' turn off the opposite tics so the Y tics don't show up on the Y2 axis
        myPane.YAxis.MajorTic.IsOpposite = True
        myPane.YAxis.MinorTic.IsOpposite = True
        ' Don't display the Y zero line
        myPane.YAxis.MajorGrid.IsZeroLine = True
        ' Align the Y axis labels so they are flush to the axis
        myPane.YAxis.Scale.Align = AlignP.Inside
        ' Manually set the axis range
        myPane.YAxis.Scale.Min = 0 '-30
        myPane.YAxis.Scale.Max = 20000 '30


        'zoom auto on axes x et y
        myPane.XAxis.Scale.MinAuto = True
        myPane.XAxis.Scale.MaxAuto = True
        myPane.YAxis.Scale.MinAuto = True
        myPane.YAxis.Scale.MaxAuto = True
        myPane.Y2Axis.Scale.MinAuto = True
        myPane.Y2Axis.Scale.MaxAuto = True


        ' Enable the Y2 axis display
        myPane.Y2Axis.IsVisible = True
        ' Make the Y2 axis scale blue
        myPane.Y2Axis.Scale.FontSpec.FontColor = Color.Blue
        myPane.Y2Axis.Title.FontSpec.FontColor = Color.Blue
        ' turn off the opposite tics so the Y2 tics don't show up on the Y axis
        myPane.Y2Axis.MajorTic.IsOpposite = True
        myPane.Y2Axis.MinorTic.IsOpposite = True
        ' Display the Y2 axis grid lines
        myPane.Y2Axis.MajorGrid.IsVisible = True
        ' Align the Y2 axis labels so they are flush to the axis
        myPane.Y2Axis.Scale.Align = AlignP.Inside
        ' Manually set the axis range
        myPane.Y2Axis.Scale.Min = 0 '-30
        myPane.Y2Axis.Scale.Max = 20000 '30

        ' Fill the axis background with a gradient
        myPane.Chart.Fill = New Fill(Color.White, Color.LightGray, 45.0F)

        ' Add a text box with instructions
        Dim text As New TextObj("Zoom: left mouse & drag" & Chr(10) & _
                                "Pan: middle mouse & drag" & Chr(10) & _
                                "Context Menu: right mouse", 0.05F, 0.95F,
                                CoordType.ChartFraction, AlignH.Left, AlignV.Bottom)
        text.FontSpec.StringAlignment = StringAlignment.Near
        myPane.GraphObjList.Add(text)

        ' Enable scrollbars if needed
        zg1.IsShowHScrollBar = True
        zg1.IsShowVScrollBar = True
        zg1.IsAutoScrollRange = True
        zg1.IsScrollY2 = True

        zg1.IsShowPointValues = True

        ' Size the control to fit the window
        SetSize()

        ' Tell ZedGraph to calculate the axis ranges
        ' Note that you MUST call this after enabling IsAutoScrollRange, since AxisChange() sets
        ' up the proper scrolling parameters
        zg1.AxisChange()
        ' Make sure the Graph gets redrawn
        zg1.Invalidate()

        'update datalogger
        TimerDataLogger.Enabled = True
    End Sub

    ' On resize action, resize the ZedGraphControl to fill most of the Form, with a small
    ' margin around the outside
    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        SetSize()
    End Sub

    Private Sub SetSize()
        Dim loc As New Point(10, 15)
        zg1.Location = loc
        ' Leave a small margin around the outside of the control
        Dim size As New Size(Me.ClientRectangle.Width - 40, Me.ClientRectangle.Height - 370)
        zg1.Size = size
    End Sub

    'Display customized tooltips when the mouse hovers over a point
    Private Function MyPointValueEvent(ByVal control As ZedGraphControl, ByVal pane As GraphPane, ByVal curve As CurveItem, ByVal iPt As Integer) As String
        ' Get the PointPair that is under the mouse
        Dim pt As PointPair = curve(iPt)
        Return curve.Label.Text + " = " + pt.Y.ToString + " tours/mn  à " + pt.X.ToString '+ " seconde"
        'Dim myDate As Date = DateTime.ParseExact(pt.X.ToString("f0"), "yyMMddHHmm", CultureInfo.InvariantCulture)
        'Return curve.Label.Text + " = " + pt.Y.ToString + " tours/mn  à " + myDate '+ " seconde"
    End Function

    ' Customize the context menu by adding a new item to the end of the menu
    Private Sub MyContextMenuBuilder(ByVal control As ZedGraphControl, ByVal menu As ContextMenuStrip, ByVal mousePt As Point, ByVal objState As ZedGraphControl.ContextMenuObjectState)
        Dim item As New ToolStripMenuItem
        item.Name = "add-beta"
        item.Tag = "add-beta"
        item.Text = "Add a new Beta Point"
        AddHandler item.Click, AddressOf Me.AddBetaPoint

        menu.Items.Add(item)
    End Sub

    ' Handle the "Add New Beta Point" context menu item.  This finds the curve with
    ' the CurveItem.Label = "Beta", and adds a new point to it.
    Private Sub AddBetaPoint(ByVal sender As Object, ByVal args As EventArgs)
        ' Get a reference to the "Beta" curve PointPairList
        Dim x As Double, y As Double

        Dim ip As IPointListEdit = zg1.GraphPane.CurveList("Vitesse1").Points

        If (Not IsNothing(ip)) Then
            x = ip.Count * 5.0
            y = ip.Count
            ip.Add(x, y)
            zg1.AxisChange()
            zg1.Refresh()
        End If
    End Sub

    Private Sub zg1_ZoomEvent(ByVal control As ZedGraphControl, ByVal oldState As ZoomState, ByVal newState As ZoomState)
        'Here we get notification everytime the user zooms
    End Sub

    Private Sub TimerDataLogger_Tick(sender As System.Object, e As System.EventArgs) Handles TimerDataLogger.Tick
        zg1.IsAutoScrollRange = True
        ' Tell ZedGraph to calculate the axis ranges
        ' Note that you MUST call this after enabling IsAutoScrollRange, since AxisChange() sets
        ' up the proper scrolling parameters
        zg1.AxisChange()
        'zg1.Refresh()
        ' Make sure the Graph gets redrawn
        zg1.Invalidate()
    End Sub


    Private Sub btnSend_Click(sender As System.Object, e As System.EventArgs) Handles btnSend.Click
        If SerialPort1.IsOpen() Then
            SerialPort1.Write(txtMessage.Text)
            txtMessage.Text = ""

        End If
    End Sub


    Private Sub ButtonAuxMini_Click(sender As System.Object, e As System.EventArgs) Handles ButtonAuxMini.Click
        PictureBoxAuxMini.Image = My.Resources.rectangle_vert
        PictureBoxAuxMiddle.Image = My.Resources.rectangle_rouge
        PictureBoxAuxMaxi.Image = My.Resources.rectangle_rouge
        LabelAux.Text = 0
        ProgressBarAuxiliary.Value = 0
        SerialPort1.Write(Trim(Str(181)) & vbCr)

    End Sub

    Private Sub ButtonAuxMiddle_Click(sender As System.Object, e As System.EventArgs) Handles ButtonAuxMiddle.Click
        PictureBoxAuxMini.Image = My.Resources.rectangle_rouge
        PictureBoxAuxMiddle.Image = My.Resources.rectangle_vert
        PictureBoxAuxMaxi.Image = My.Resources.rectangle_rouge
        LabelAux.Text = 90
        ProgressBarAuxiliary.Value = 90
        SerialPort1.Write(Trim(Str(270)) & vbCr)
    End Sub

    Private Sub ButtonAuxMaxi_Click(sender As System.Object, e As System.EventArgs) Handles ButtonAuxMaxi.Click
        PictureBoxAuxMini.Image = My.Resources.rectangle_rouge
        PictureBoxAuxMiddle.Image = My.Resources.rectangle_rouge
        PictureBoxAuxMaxi.Image = My.Resources.rectangle_vert
        LabelAux.Text = 180
        ProgressBarAuxiliary.Value = 180
        SerialPort1.Write(Trim(Str(360)) & vbCr)
    End Sub

 
    Private Sub ButtonGlowPlugOnOff_Click(sender As System.Object, e As System.EventArgs) Handles ButtonGlowPlugOnOff.Click
        GlowPlugIsOn = Not GlowPlugIsOn
        SerialPort1.Write(Trim(Str(369)) & vbCr)
        If GlowPlugIsOn = True Then
            PictureBoxGlowPlugOnOff.Image = My.Resources.rectangle_vert
        Else
            PictureBoxGlowPlugOnOff.Image = My.Resources.rectangle_rouge
        End If

    End Sub
End Class


