﻿Imports System.IO
Imports System.IO.Ports

Module Module1
    Public pos As Integer = 0
    Public posAux As Integer = 0
    Public posRudder As Integer = 0
    Public ReadSettings As String
    Public array() As String
    Public MessageToSend As String
    Public ModeType As Integer
    Public SpeedArray() As String
    Public myRectangle As Rectangle
    Public HardwareArray() As String
    Public watch As Stopwatch
    Public pulseValue As Integer = 0
    Public pulseMinValue As Integer = 0
    Public pulseMaxValue As Integer = 0


End Module
