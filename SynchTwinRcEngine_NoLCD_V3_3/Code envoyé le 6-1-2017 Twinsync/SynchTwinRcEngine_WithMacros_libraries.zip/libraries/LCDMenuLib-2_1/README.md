Arduino LCDMenuLib with layers, 4Bit, 8Bit, I2C, ShiftReg, DogLCD
=================================================================
*  max 254 menu elements												
*  max 254 menu elements per layer								    
*  max 6 layers from root, configurable in LCDMenuLib___config.h				
*  max support for 6 buttons up, down, left, right, back/quit, enter  
*  min 3 buttons needed up, down, enter                               
*  separation of structural and functional level                     
*  support for initscreen which is shown after x secounds or at begin (configurable) 
*  scrollbar when more menu elments in a layer then rows              
*  last cursor pos is saved											
*  possibility to jump from one menu elment directly to another       
*  support for many different lcd librarys in LCDMenuLib___config.h   
*  4bit lcd support													
*  8bit lcd support													
*  i2c lcd support													
*  shift register lcd support											
*  DogLcd support
*  the menu function are only updated when a button is hit or a trigger is set														
*  different triggers for display function
*  backend system to manage programs behind the shown menu elements 																		 
*  many small function for other things								
*																		
*  no support for gaphic displays yet									

Examples in english

Description & Support (german):
http://forum.arduino.cc/index.php?topic=73816.0



